(** Pricklypear Image — HTTP shared infrastructure.
    Responses, chrome, forms, auth gate helpers, login/admin.
    Page handlers live in [Http_pages]; dispatch in [Http]. *)
open Pure_html

let default_port = 8080

(* ------------------------------------------------------------------
   PEER-DISCONNECT SAFETY (image.http-robustness invariants 1-2).

   httpaf raises Failure("cannot write to closed writer") when you write
   to a response whose client has already disconnected. Under real
   traffic (people aborting page loads) an uncaught instance of this
   exception killed the single-image process repeatedly (prod incident
   2026-07-16). Every response write must tolerate a gone peer.
   Promoted from http_agent.ml's SSE-only guard; shared by all response
   helpers + the httpaf error_handler. *)
let is_closed_writer_exn (exn : exn) : bool =
  match exn with
  | Failure msg ->
      String.equal msg "cannot write to closed writer"
      || String.starts_with ~prefix:"cannot write to closed writer" msg
  | _ -> false

(** Write a response body string, swallowing the closed-writer Failure
    that httpaf raises when the peer has gone. Returns () either way. *)
let safe_respond_with_string (reqd : Httpun.Reqd.t)
    (resp : Httpun.Response.t) (body : string) : unit =
  try Httpun.Reqd.respond_with_string reqd resp body
  with exn when is_closed_writer_exn exn -> ()

(** Close a body writer, swallowing the closed-writer Failure. *)
let safe_close_writer (body : Httpun.Body.Writer.t) : unit =
  try Httpun.Body.Writer.close body
  with exn when is_closed_writer_exn exn -> ()

(* ------------------------------------------------------------------
   ACCEPT-SIDE CONNECTION CAP (image.http-robustness invariant 5).

   Bounds in-flight requests so a traffic spike can't exhaust fds or
   memory. Default 256; configurable via PP_HTTP_MAX_INFLIGHT. Requests
   beyond the cap are rejected with 503 instead of being accepted into
   an unbounded queue. This is a safety valve, not a throughput target. *)
let max_inflight =
  match Sys.getenv_opt "PP_HTTP_MAX_INFLIGHT" with
  | Some s -> (match int_of_string_opt s with Some n when n > 0 -> n | _ -> 256)
  | None -> 256

(* Counting gate for concurrent in-flight page work (Eio floor).
   Overflow waits for a slot rather than consuming unbounded memory/fds. *)
type inflight_gate = {
  mutable count : int;
  limit : int;
  mutex : Eio.Mutex.t;
  cond : Eio.Condition.t;
}

let inflight_sem =
  { count = 0; limit = max_inflight;
    mutex = Eio.Mutex.create (); cond = Eio.Condition.create () }

let inflight_acquire () : unit =
  Eio.Mutex.lock inflight_sem.mutex;
  while inflight_sem.count >= inflight_sem.limit do
    Eio.Condition.await inflight_sem.cond inflight_sem.mutex
  done;
  inflight_sem.count <- inflight_sem.count + 1;
  Eio.Mutex.unlock inflight_sem.mutex

let inflight_release () : unit =
  Eio.Mutex.lock inflight_sem.mutex;
  inflight_sem.count <- inflight_sem.count - 1;
  Eio.Condition.broadcast inflight_sem.cond;
  Eio.Mutex.unlock inflight_sem.mutex

(* ------------------------------------------------------------------
   PER-IDENTITY FAIR-SHARE (card 1bdeb856). The global 256 gate alone
   lets one authenticated tenant park ~256 in-budget-but-slow evals
   ((sleep 60) chains are in-budget) and starve every other tenant,
   including anonymous public routes queued behind the same gate.
   security.borg budgets-are-security: limiter units should be THE
   RESOURCE, so a small per-username concurrent-eval bucket is checked
   IN ADDITION to the global cap.

   Applied AFTER identity attach (the global gate is acquired before
   identity is known), wrapping page_fn only. Anonymous traffic shares
   one bucket keyed "anonymous". Default 4; PP_HTTP_MAX_INFLIGHT_PER_USER
   overrides (<=0 disables the per-identity check). *)
let max_inflight_per_user =
  match Sys.getenv_opt "PP_HTTP_MAX_INFLIGHT_PER_USER" with
  | Some s -> (match int_of_string_opt s with Some n -> n | _ -> 4)
  | None -> 4

type per_user_gate = {
  mutable counts : (string * int) list;
  mutex : Eio.Mutex.t;
  cond : Eio.Condition.t;
}

let per_user_sem =
  { counts = []; mutex = Eio.Mutex.create (); cond = Eio.Condition.create () }

let per_user_acquire (user : string) : unit =
  if max_inflight_per_user > 0 then begin
    Eio.Mutex.lock per_user_sem.mutex;
    let rec wait () =
      let n = try List.assoc user per_user_sem.counts with Not_found -> 0 in
      if n >= max_inflight_per_user then begin
        Eio.Condition.await per_user_sem.cond per_user_sem.mutex;
        wait ()
      end
      else
        let counts =
          (user, n + 1)
          :: List.remove_assoc user per_user_sem.counts
        in
        per_user_sem.counts <- counts
    in
    wait ();
    Eio.Mutex.unlock per_user_sem.mutex
  end

let per_user_release (user : string) : unit =
  if max_inflight_per_user > 0 then begin
    Eio.Mutex.lock per_user_sem.mutex;
    let n = try List.assoc user per_user_sem.counts with Not_found -> 0 in
    let counts =
      if n <= 1 then List.remove_assoc user per_user_sem.counts
      else (user, n - 1) :: List.remove_assoc user per_user_sem.counts
    in
    per_user_sem.counts <- counts;
    Eio.Condition.broadcast per_user_sem.cond;
    Eio.Mutex.unlock per_user_sem.mutex
  end

let emergency_css : string =
  (* Labeled recovery only — NOT the product design system.
     Product CSS comes from Lisp (ui/css) via Session.ui_css. *)
  "/* emergency-css */\n\
   body{font-family:ui-monospace,Menlo,monospace;margin:1rem;\n\
   background:#fff3cd;color:#1a1a1a;line-height:1.4}\n\
   .emergency-banner{display:block;width:100%;padding:.4rem .55rem;\n\
   border:2px solid #8b0000;background:#fff3cd;color:#1a1a1a;\n\
   font-size:.85rem;font-family:Courier,monospace;margin:.35rem 0}\n\
   .emergency-banner a{color:#000080}\n\
   nav.emergency-nav{width:100%;margin-top:.35rem}\n\
   .emergency-home{border:2px solid #8b0000;background:#fff3cd;padding:.75rem}\n\
   a{color:#000080}\n\
   header{border-bottom:2px solid #000;padding:.5rem;background:#fff}\n\
   main{padding:.75rem}\n\
   .card{border:2px solid #000;background:#fff;padding:.75rem;margin:.5rem 0}\n\
   .err{color:#8b0000;font-weight:700}\n\
   .ok{color:#006600;font-weight:700}\n\
   button,.btn,input[type=submit]{font:inherit;padding:.45rem .75rem;\n\
   border:2px solid #000;background:#eee;cursor:pointer}\n\
   table{border-collapse:collapse;width:100%}\n\
   th,td{border:1px solid #808080;padding:.35rem}\n\
   pre,textarea,input[type=text],input[type=password]{\n\
   font-family:ui-monospace,Menlo,monospace;width:100%;\n\
   box-sizing:border-box;border:1px solid #000;padding:.4rem}\n\
   .badge.impact{background:#ffe8a3;border:1px solid #8b6914;padding:.15rem .4rem}\n\
   .bb-browser{display:flex;flex-direction:column;gap:.75rem}\n\
   .bb-three{display:block}\n\
   .bb-three .bb-col{margin:.5rem 0}\n\
   .bb-list{list-style:none;padding:0;margin:.25rem 0}\n\
   .bb-item a{display:block;padding:.2rem .35rem;text-decoration:none;\n\
   border-left:3px solid transparent}\n\
   .bb-item.is-active a{font-weight:700;background:#ece9e0;border-left:3px solid #000}\n\
   .bb-source{max-height:55vh;overflow:auto;padding:.6rem;border:1px solid #000}\n\
   .bb-tabs{display:flex;gap:.35rem;flex-wrap:wrap;margin:.4rem 0 .6rem;align-items:center}\n\
   .bb-tab{display:inline-block;padding:.28rem .65rem;border:1px solid #000;\n\
   text-decoration:none;color:inherit;background:#f7f5ef;border-radius:2px}\n\
   .bb-tab:hover{background:#ece9e0}\n\
   .bb-tab.is-active{background:#1a1a1a;color:#f7f5ef;font-weight:700}\n\
   .bb-edit-form textarea{width:100%;min-height:14rem;font-family:ui-monospace,monospace}\n\
   .bb-code .bb-edit-form .card{border:none;padding:0;box-shadow:none}\n\
   .ast-walk .ast-self-ref{background:#fff3bf;border-bottom:2px solid #e67700}\n\
   .ast-walk .ast-tail{box-shadow:inset 3px 0 0 #2b8a3e}\n\
   .ast-walk .ast-non-tail{box-shadow:inset 3px 0 0 #c92a2a}\n\
   .ast-walk .ast-mutual{background:#e7f5ff;border-bottom:2px dashed #1971c2}\n\
   .badge.complexity{background:#e7f5ff;border:1px solid #1971c2;padding:.1rem .35rem}\n\
   .badge.db-cost{background:#f3f0ff;border:1px solid #5f3dc4;padding:.1rem .35rem}\n\
   .badge.ast-tail{background:#d3f9d8;border:1px solid #2b8a3e;padding:.1rem .35rem}\n\
   .badge.ast-non-tail{background:#ffe3e3;border:1px solid #c92a2a;padding:.1rem .35rem}\n\
   .explain-layer,.explain-panel{margin-top:.5rem}\n\
   .analyze-result{margin-top:.5rem}\n\
   @media (min-width:900px){\n\
   .bb-three{display:grid;grid-template-columns:12rem 14rem 1fr;gap:.75rem;\n\
   align-items:stretch;min-height:16rem}\n\
   .bb-three .bb-col{max-height:42vh;overflow:auto;margin:0}\n\
   }\n\
   "

(** HSTS max-age is on by default: 180 days, no includeSubDomains (the
    garden subdomains are the reason — a bad cert would otherwise lock
    every garden out) and no preload. Set PP_HSTS_MAX_AGE=0 to disable
    (plain-HTTP dev; a browser would otherwise force https on
    localhost). i-1787970880 residual: HSTS was absent entirely. *)
let hsts_max_age () : int =
  match Sys.getenv_opt "PP_HSTS_MAX_AGE" with
  | Some v -> (match int_of_string_opt (String.trim v) with Some n -> max 0 n | None -> 15552000)
  | None -> 15552000

(** Security headers appended to every response. Deliberately NOT a full
    CSP: the chrome relies on inline <style>/<script> (htmx + outline
    client script), so we only pin frame-ancestors 'none'.

    HSTS is emitted unconditionally when enabled: browsers IGNORE
    Strict-Transport-Security received over plain HTTP (RFC 6797), so a
    dev server on http is unaffected while a TLS edge gets the header on
    its very first https response. Disable with PP_HSTS_MAX_AGE=0. *)
let security_headers () : (string * string) list =
  let base =
    [ ("x-content-type-options", "nosniff")
    ; ("x-frame-options", "DENY")
    ; ("referrer-policy", "strict-origin-when-cross-origin")
    ; ("content-security-policy", "frame-ancestors 'none'")
    ]
  in
  if hsts_max_age () > 0 then
    ("strict-transport-security",
     Printf.sprintf "max-age=%d" (hsts_max_age ()))
    :: base
  else base

let html_response (reqd : Httpun.Reqd.t) ?(status = `OK)
    ?session ?(css : string option) (body : Pure_html.node) : unit =
  let css =
    match css with
    | Some c when String.trim c <> "" -> c
    | _ ->
        (match session with
         | Some s ->
             (match Session.ui_css s with
              | Some c when String.trim c <> "" -> c
              | _ -> emergency_css)
         | None -> emergency_css)
  in
  let html_doc = HTML.html [HTML.lang "en"] [
    HTML.head [] [
      HTML.title [] "Pricklypear";
      HTML.meta [HTML.charset "utf-8"];
      (* Mobile-first: prevent tiny text, enable proper layout *)
      HTML.meta [HTML.name "viewport";
                 HTML.content "width=device-width, initial-scale=1"];
      HTML.style [] "%s" css;

      (* htmx 4 (vendored, no CDN — see borge/multipart.borg stance) +
         htmx-2-compat: restores implicit attribute inheritance, 1.9/2.x
         error no-swap defaults, and old camelCase event names so existing
         markup keeps htmx 1.9 semantics during incremental migration. *)
      HTML.script [HTML.src "/assets/htmx.min.js"] "";
      HTML.script [HTML.src "/assets/htmx-2-compat.min.js"] "";
      (* hx-optimistic: official htmx 4 extension (vendored, no CDN). Loaded
         globally so it registers before any hx-optimistic attribute is
         processed. Display-placeholder optimism only — see
         borge/structural-editing.borg RESPONSIVENESS WITHOUT PREDICTION.
         Inert on pages that don't use the attribute. *)
      HTML.script [HTML.src "/assets/hx-optimistic.js"] "";
      (* idiomorph: standalone morph library (diff-based DOM
         reconciliation) so optimistic local renders converge to server
         truth without clobbering focus/selection. Called directly as
         Idiomorph.morph(target, source) from the outline client script —
         NOT registered as an htmx extension (htmx 4 renamed
         defineExtension -> registerExtension; idiomorph-ext still uses
         the old API). Spec: borge/structural-editing.borg client-eval. *)
      HTML.script [HTML.src "/assets/idiomorph.min.js"] "";
      (* Nav menus are pure HTML/CSS: exclusive open comes from the
         native <details name=...> accordion attribute (menu/render),
         so no menu JS here. Remaining script: outline summaries only
         toggle collapse via the .ol-fold handle. *)
      HTML.script [] "%s"
        ("document.addEventListener('click',function(e){" ^
         "var sum=e.target&&e.target.closest?e.target.closest('summary.ol-sum'):null;" ^
         "if(sum&&!(e.target.closest&&e.target.closest('.ol-fold'))){e.preventDefault();}" ^
         "});");
    ];
    HTML.body [] [body];
  ] in
  let s = Pure_html.to_string html_doc in
  let headers =
    Httpun.Headers.of_list
      ([("content-type", "text/html; charset=utf-8");
        ("content-length", string_of_int (String.length s))]
       @ Timing.timing_header ()
       @ security_headers ())
  in
  let resp = Httpun.Response.create ~headers status in
  safe_respond_with_string reqd resp s

let text_response (reqd : Httpun.Reqd.t) ?(status = `OK) ~content_type
    ?(cache : int option) (s : string) : unit =
  (* Optional public caching (product-experience.html-builders
     layout.css-face): the stylesheet face passes the max-age seconds
     from the bytes-response sentinel. max_age > 0 -> long-lived
     immutable entry; 0 (or absent) -> no Cache-Control header, the
     pre-existing behavior everywhere else. *)
  let cache_headers =
    match cache with
    | Some secs when secs > 0 ->
      [ ("cache-control",
         "public, max-age=" ^ string_of_int secs ^ ", immutable") ]
    | Some _ -> [ ("cache-control", "no-cache") ]
    | None -> []
  in
  let headers =
    Httpun.Headers.of_list
      ([("content-type", content_type);
        ("content-length", string_of_int (String.length s))]
       @ cache_headers
       @ Timing.timing_header ()
       @ security_headers ())
  in
  let resp = Httpun.Response.create ~headers status in
  safe_respond_with_string reqd resp s

let json_response (reqd : Httpun.Reqd.t) ?(status = `OK) (j : Yojson.Safe.t) : unit =
  let s = Yojson.Safe.to_string j in
  text_response reqd ~status ~content_type:"application/json" s

(** Labeled emergency nav only — NOT a product menu twin.
    Product chrome is Lisp (ui/nav). See image.system-browser. *)
let emergency_nav_nodes () : Pure_html.node list =
  [ HTML.span [HTML.class_ "emergency-banner"]
      [ txt "EMERGENCY NAV — ui/nav missing or failed · "
      ; HTML.a [HTML.href "/bindings?pkg=ui"] [txt "fix ui shell"]
      ; txt " · "
      ; HTML.a [HTML.href "/"] [txt "home"]
      ; txt " · "
      ; HTML.a [HTML.href "/login"] [txt "login"]
      ; txt " · "
      ; HTML.a [HTML.href "/health"] [txt "health"]
      ]
  ]

let value_to_html_string (v : Pricklypear_lisp.Ast.value) : string =
  match Primitives.is_raw_html v with
  | Some s -> s
  | None ->
      (match v with
       | Pricklypear_lisp.Ast.VStr s -> s
       | _ -> Pricklypear_lisp.Reader.pp_value v)

let try_ui_fn (session : Session.t) (name : string) : string option =
  (try
      let r = Session.call_handler session name in
      match r with
      | Session.Handler_ok v -> (Some (value_to_html_string v))
      | Session.Handler_unbound ->
          Printf.eprintf "[http] try_ui_fn %s: unbound\n%!" name;
          None
      | Session.Handler_error msg ->
          Printf.eprintf "[http] try_ui_fn %s: %s\n%!" name msg;
          None
    with exn ->
      Printf.eprintf "[http] try_ui_fn %s failed: %s\n%!"
        name (Printexc.to_string exn);
      None)

(** Fragment / partial: no document chrome (htmx swap target). *)
let is_partials_path (path : string) : bool =
  String.length path >= 10 && String.sub path 0 10 = "/partials/"

let header_list (req : Httpun.Request.t) : (string * string) list =
  Httpun.Headers.to_list req.headers
  |> List.map (fun (k, v) -> (String.lowercase_ascii k, v))

let wants_fragment ~(path : string) ~(headers : (string * string) list) : bool =
  if is_partials_path path then true
  else
    match List.assoc_opt "hx-request" headers with
    | Some v when v <> "" && String.lowercase_ascii v <> "false" -> true
    | _ -> false

(* ---------- Auth (single-image Option B: in-process sessions) ---------- *)

let cookie_name = "pp_session"

(** Per-user subdomains (auth.user-subdomains). Empty PP_BASE_DOMAIN = off. *)
let base_domain () =
  match Sys.getenv_opt "PP_BASE_DOMAIN" with
  | Some s when String.trim s <> "" -> Some (String.lowercase_ascii (String.trim s))
  | _ -> None

let host_header (headers : (string * string) list) : string option =
  let rec find = function
    | [] -> None
    | (k, v) :: _ when String.lowercase_ascii k = "host" ->
        let host =
          match String.index_opt v ':' with
          | Some i -> String.sub v 0 i
          | None -> v
        in
        Some (String.lowercase_ascii host)
    | _ :: rest -> find rest
  in
  find headers

type host_mode =
  | Host_legacy
  | Host_apex
  | Host_garden of string
  | Host_userbranch of string * string  (* face.{user}.{base}: user + reserved face *)
  | Host_unknown

let username_dns_ok (name : string) : bool =
  let n = String.length name in
  n > 0 && n <= 63
  && (match name.[0] with 'a' .. 'z' | '0' .. '9' -> true | _ -> false)
  && (match name.[n - 1] with 'a' .. 'z' | '0' .. '9' -> true | _ -> false)
  &&
  let rec loop i =
    if i >= n then true
    else
      match name.[i] with
      | 'a' .. 'z' | '0' .. '9' | '-' -> loop (i + 1)
      | _ -> false
  in
  loop 0

(* auth.branch-faces (2026-10-12): reserved face labels for second-level
   hosts — a CLOSED set fixed in code (adding a label is a kernel change,
   not data). *)
let reserved_faces = [ "agent"; "dev" ]

let classify_host (headers : (string * string) list) : host_mode =
  match base_domain (), host_header headers with
  | None, _ -> Host_legacy
  | Some base, None -> Host_apex
  | Some base, Some host ->
      if host = base then Host_apex
      else
        let suffix = "." ^ base in
        let hl = String.length host
        and sl = String.length suffix in
        if hl > sl && String.sub host (hl - sl) sl = suffix then
          let name = String.sub host 0 (hl - sl) in
          if not (String.contains name '.') then begin
            if username_dns_ok name then Host_garden name else Host_unknown
          end
          else
            (* {face}.{user}.{base}: first label in the reserved set, second a
               DNS-ok username; anything else is Host_unknown exactly as before
               (single-label gardens unchanged). *)
            (match String.split_on_char '.' name with
             | [ face; user ] when List.mem face reserved_faces ->
                 if username_dns_ok user then Host_userbranch (user, face)
                 else Host_unknown
             | _ -> Host_unknown)
        else Host_unknown

let garden_url ~(username : string) ~(path : string) : string =
  match base_domain () with
  | None -> path
  | Some base ->
      let p = if path = "" then "/" else path in
      "https://" ^ username ^ "." ^ base ^ p

(** Serialize request identity attach — cotenant multi-user shares one
    Session.t; concurrent Alice/Bob would otherwise race branch/env. *)
let request_mutex = Eio.Mutex.create ()

let auth_disabled () : bool =
  match Sys.getenv_opt "PP_AUTH_DISABLED" with
  | Some ("1" | "true" | "TRUE" | "yes" | "YES") -> true
  | _ -> false

let has_prefix (path : string) (prefix : string) : bool =
  path = prefix
  || (String.length path > String.length prefix
      && String.sub path 0 (String.length prefix) = prefix
      && path.[String.length prefix] = '/')

(* The five chrome-free front-door pages (http.ml renders them without
   product nav). Single source of truth: the hard-public gate below and
   http.ml's renderer both read this list, so a page cannot be public in
   one layer and undocumented in another. *)
let front_door_pages =
  [ "/welcome"; "/background"; "/roadmap"; "/signup"; "/guestbook" ]

let is_system_hard_public (path : string) : bool =
  path = "/login"
  || path = "/health"
  || path = "/logout"
  || List.mem path front_door_pages
  || path = "/book.pdf"
  || path = "/src.tgz"
  || path = "/code"
  || has_prefix path "/code"
  || path = "/assets"
  || has_prefix path "/assets"
  || path = "/.well-known/agent.json"
  || path = "/agent.txt"
  (* one-tree.tree-browser: the store-tree face renders for anonymous
     sessions CONFINED to public prefixes (data.shared, own garden,
     the anonymous lens's main store-tree) — private paths are not
     listable (path_visible in Http_tree enforces it; POST /tree/edit
     stays private + anonymous-denied). *)
  || path = "/tree"
  || path = "/partials/tree"

(** Kernel paths Lisp cannot open to the world (auth.route-visibility). *)
let is_system_hard_private (path : string) : bool =
  let prefixes =
    [ "/admin"
    ; "/analytics"
    ; "/data"
    ; "/api"
    ; "/media"
    ; "/bindings"
    ; "/binding"
    ; "/diff"
    ; "/edit"
    ; "/repl"
    ; "/branches"
    ; "/types"
    ; "/pages"
    ; "/page"
    ; "/inspect"
    ; "/agent"
    ]
  in
  List.exists
    (fun p ->
      path = p
      || (String.length path > String.length p
          && String.sub path 0 (String.length p) = p
          && path.[String.length p] = '/'))
    prefixes
  || path = "/"

type path_class =
  [ `Hard_public | `Hard_private | `User of string * string | `Unknown ]

(** Classify path against a routes table. The table is the per-request
    snapshot when called post-gate (image.per-request-context), or the
    live Session.routes when called under the request_mutex (pre-gate —
    attach has not run for THIS request, but the mutex excludes concurrent
    rehydrate, so live is correct there). Returns `User (handler, visibility). *)
let classify_path_with_routes
    (routes : (string, string * string) Hashtbl.t) (path : string) : path_class =
  if is_system_hard_public path then `Hard_public
  else if is_system_hard_private path then `Hard_private
  else
    match Hashtbl.find_opt routes path with
    | Some (handler, vis) -> `User (handler, vis)
    | None ->
        (* notes-cross read (note-vis-p1): /notes/<user>/<slug> is a
           framework route outside the user-routes table, and the vis
           floor in tree/find-by is the real gate (the lib never decides
           visibility). Anonymous callers reach the handler, which
           renders public rows and a bare not-found for private/users;
           bad path shapes 400. User routes registered at a /notes/ path
           keep their own vis classification above. *)
        if String.starts_with ~prefix:"/notes/" path
           && String.length path > String.length "/notes/"
        then `Hard_public
        else `Unknown

(** Classify path for the request gate.
    Returns [`Hard_public | `Hard_private | `User of string * string
    | `Unknown] where User is (handler, visibility). *)
let classify_path (session : Session.t) (path : string) : path_class =
  classify_path_with_routes (Session.routes session) path

let parse_cookies (headers : (string * string) list) : (string * string) list =
  match List.assoc_opt "cookie" headers with
  | None -> []
  | Some raw ->
      String.split_on_char ';' raw
      |> List.filter_map (fun part ->
             let part = String.trim part in
             match String.index_opt part '=' with
             | None -> None
             | Some i ->
                 let k = String.trim (String.sub part 0 i) in
                 let v =
                   String.trim
                     (String.sub part (i + 1) (String.length part - i - 1))
                 in
                 if k = "" then None else Some (k, v))

let cookie_value (headers : (string * string) list) (name : string)
  : string option =
  List.assoc_opt name (parse_cookies headers)

let b64_decode_opt (s : string) : string option =
  match Base64.decode ~pad:true s with
  | Ok raw -> Some raw
  | Error _ ->
      (match Base64.decode ~pad:false s with
       | Ok raw -> Some raw
       | Error _ -> None)

(** Parse "Basic base64(user:pass)" Authorization header. *)
let parse_basic_auth (headers : (string * string) list)
  : (string * string) option =
  match List.assoc_opt "authorization" headers with
  | None -> None
  | Some v ->
      let v = String.trim v in
      if String.length v < 7 then None
      else
        let scheme = String.lowercase_ascii (String.sub v 0 5) in
        if scheme <> "basic" then None
        else
          let b64 = String.trim (String.sub v 5 (String.length v - 5)) in
          match b64_decode_opt b64 with
          | None -> None
          | Some decoded ->
              (match String.index_opt decoded ':' with
               | None -> None
               | Some i ->
                   let u = String.sub decoded 0 i in
                   let p =
                     String.sub decoded (i + 1)
                       (String.length decoded - i - 1)
                   in
                   Some (u, p))

(** Parse an Authorization: Bearer <token> header. Returns the raw token. *)
let parse_bearer_auth (headers : (string * string) list) : string option =
  match List.assoc_opt "authorization" headers with
  | None -> None
  | Some v ->
      let v = String.trim v in
      if String.length v < 8 then None
      else
        let scheme = String.lowercase_ascii (String.sub v 0 6) in
        if scheme <> "bearer" then None
        else Some (String.trim (String.sub v 6 (String.length v - 6)))

(** Cheap pre-identity key for the per-identity fair-share gate
    (card 1bdeb856): used BEFORE identity attach, so it cannot read the
    username. The credential the request presents IS the identity for
    gating purposes, so hash the session cookie / Bearer token (never
    the raw secret), and fall back to Basic username or the source IP
    for anonymous logging. Returns "anonymous" when nothing is
    presented. *)
let identity_gate_key ~(headers : (string * string) list)
    ~(source_ip : string) : string =
  let h s =
    let open Digestif.SHA256 in
    to_hex (digest_string s)
  in
  match cookie_value headers cookie_name with
  | Some tok when String.trim tok <> "" -> "c:" ^ h tok
  | _ ->
      (match parse_bearer_auth headers with
       | Some tok when String.trim tok <> "" -> "b:" ^ h tok
       | _ ->
           (match parse_basic_auth headers with
            | Some (u, _) when String.trim u <> "" -> "u:" ^ u
            | _ ->
                if String.trim source_ip = "" then "anonymous"
                else "ip:" ^ source_ip))

(** Emit "; Secure" on the session cookie.

    i-1787970928 follow-up: the original rule was `Secure only when
    PP_BASE_DOMAIN is set`, which made the flag INEFFECTIVE ON PROD —
    prod serves https://pricklypear.rocks with no base domain, so it
    emitted a cookie a browser may send over plain http (verified live
    2026-10-01: /login Set-Cookie had no Secure).

    Resolution order:
      1. PP_COOKIE_SECURE=1/true  -> force ON  (works with or without
         a base domain; the correct prod setting behind a TLS edge).
      2. PP_COOKIE_SECURE=0/false -> force OFF (plain-HTTP dev).
      3. unset -> fall back to the original heuristic (base domain set
         implies https). Kept so existing deployments do not regress. *)
let cookie_secure () : bool =
  match Sys.getenv_opt "PP_COOKIE_SECURE" with
  | Some v ->
      let v = String.trim (String.lowercase_ascii v) in
      (match v with
       | "" -> base_domain () <> None
       | "0" | "false" | "no" -> false
       | _ -> true)
  | None -> base_domain () <> None

(** [true] when the request arrived over TLS at the edge, judged from
    X-Forwarded-Proto (nginx sets it). Used to auto-emit Secure so a
    TLS-terminating edge need not remember PP_COOKIE_SECURE. *)
let request_is_https (headers : (string * string) list) : bool =
  let rec find = function
    | [] -> false
    | (k, v) :: _ when String.lowercase_ascii k = "x-forwarded-proto" ->
        (match String.index_opt v ',' with
         | Some i -> String.lowercase_ascii (String.trim (String.sub v 0 i)) = "https"
         | None -> String.lowercase_ascii (String.trim v) = "https")
    | _ :: rest -> find rest
  in
  find headers

let set_cookie_header ?(force_secure = false) ~(token : string) () : string =
  (* Path=/; HttpOnly; SameSite=Lax. PP_BASE_DOMAIN scopes cookie across
     subdomains. Secure per cookie_secure (see there), OR forced when the
     live request was seen over https at the edge. *)
  let domain =
    match base_domain () with
    | Some b -> "; Domain=." ^ b
    | None -> ""
  in
  let secure = if force_secure || cookie_secure () then "; Secure" else "" in
  Printf.sprintf "%s=%s; Path=/; HttpOnly; SameSite=Lax; Max-Age=%d%s%s"
    cookie_name token (60 * 60 * 24 * 14) domain secure

let clear_cookie_header ?(force_secure = false) () : string =
  let domain =
    match base_domain () with
    | Some b -> "; Domain=." ^ b
    | None -> ""
  in
  let secure = if force_secure || cookie_secure () then "; Secure" else "" in
  Printf.sprintf
    "%s=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0%s%s" cookie_name domain
    secure

let redirect_with_cookie (reqd : Httpun.Reqd.t) ~(location : string)
    ~(set_cookie : string) : unit =
  let headers =
    Httpun.Headers.of_list
      ([ ("location", location)
       ; ("set-cookie", set_cookie)
       ; ("content-length", "0") ]
       @ security_headers ())
  in
  let resp = Httpun.Response.create ~headers `See_other in
  safe_respond_with_string reqd resp ""

let unauthorized_api (reqd : Httpun.Reqd.t) : unit =
  json_response reqd ~status:`Unauthorized
    (`Assoc
       [ ("ok", `Bool false)
       ; ("error", `String "authentication required") ])

(** i-1787971251: derive the client source_ip from the connection sockaddr
    so auth_log rows can record where a login/token use came from.
    ADDR_UNIX paths are prefixed to stay distinguishable from IPs. *)
let source_ip_of_sockaddr (sa : Unix.sockaddr) : string =
  match sa with
  | Unix.ADDR_INET (addr, _) -> Unix.string_of_inet_addr addr
  | Unix.ADDR_UNIX path -> "unix:" ^ path

(** Resolve identity for this request: cookie session, then Bearer —
    api_key first, then DELEGATED on-behalf-of token — then Basic auth.
    Returns None if unauthenticated, otherwise the resolved user (for a
    delegated hit, the OWNER) plus the actor username when carried by a
    delegated token (auth.delegation-tokens; None = self). [?source_ip]
    is propagated into the auth_log rows written by the verify calls. *)
let resolve_identity (session : Session.t)
    ~(headers : (string * string) list) ?source_ip ()
  : (Auth_store.user * string option) option =
  let store = Session.store session in
  match cookie_value headers cookie_name with
  | Some token when token <> "" ->
      (* tmp/eval-fast-path: one JOIN query for session + user (was two
         round trips: lookup_session then get_user_by_id). *)
      let user_opt = Auth_store.lookup_session_user store ~raw_token:token in
      (match user_opt with
       | Some u -> Some (u, None)
       | None ->
           (* Fall through to Basic if cookie stale. *)
           (match parse_basic_auth headers with
            | None -> None
            | Some (u, p) ->
                Auth_store.verify_password store ~username:u ~password:p
                  ?source_ip ()
                |> Option.map (fun u -> (u, None))))
  | _ ->
      (* No cookie: try Bearer token (api_key, then delegated), then Basic. *)
      (match parse_bearer_auth headers with
       | Some token when token <> "" ->
           (match Auth_store.verify_token store ~raw_token:token ?source_ip () with
            | Some u -> Some (u, None)
            | None ->
                (* Not an api_key: delegated on-behalf-of token kind.
                   Resolves (owner, actor); the session builds delegated
                   (data-only) off the OWNER. *)
                Auth_store.verify_delegated_token store ~raw_token:token
                  ?source_ip ()
                |> Option.map (fun (u, a) -> (u, Some a)))
       | _ ->
           (match parse_basic_auth headers with
            | None -> None
            | Some (u, p) ->
                Auth_store.verify_password store ~username:u ~password:p
                  ?source_ip ()
                |> Option.map (fun u -> (u, None))))

let attach_from_user (session : Session.t) (user : Auth_store.user)
    ?(auth_token : string option = None)
    ?(checkout_personal_now = false)
    ?(delegated : bool = false)
    ?(actor : string option = None)
    () : unit =
  Session.attach_identity session
    ~user_id:user.Auth_store.id
    ~username:user.Auth_store.username
    ~is_admin:user.Auth_store.is_admin
    ~auth_token
    ~checkout_personal_now
    ~user_type:user.Auth_store.user_type
    ~parent_user_id:user.Auth_store.parent_user_id
    ~delegated ~actor
    ()

let fragment_response (reqd : Httpun.Reqd.t) ?(status = `OK) (html : string)
    : unit =
  text_response reqd ~status ~content_type:"text/html; charset=utf-8" html

let chrome ?nav_html ~(session : Session.t)
    ?(manifest = Session.manifest session) ~(title : string)
    (content : Pure_html.node list) : Pure_html.node =
  let nav_html =
    match nav_html with
    | Some _ as s -> s
    | None -> Session.ui_nav_html session
  in
  let nav =
    match nav_html with
    | Some html when String.trim html <> "" ->
        HTML.nav [] [txt ~raw:true "%s" html]
    | _ -> HTML.nav [HTML.class_ "emergency-nav"] (emergency_nav_nodes ())
  in
  (* Metadata reads the SNAPSHOT manifest when callers pass one
     (image.per-request-context), so a concurrent attach_anonymous
     cannot paint "user=anonymous" on an authed page's header. Callers
     outside the HTTP gate fall back to the live session manifest. *)
  HTML.div [] [
    HTML.header [] [
      HTML.span [HTML.class_ "brand"] [txt "Pricklypear"];
      HTML.span [HTML.class_ "meta"] [
        txt "user=%s  branch=%s  up=%ds"
          manifest.username
          manifest.branch_name
          (Session.uptime_seconds session);
      ];
      nav;
    ];
    HTML.main [] (
      (if String.trim title = "" then content
       else HTML.h1 [] [txt "%s" title] :: content)
    );
  ]

let chrome_lwt ~(session : Session.t) ~(title : string)
    (content : Pure_html.node list) : Pure_html.node =
  let nav_html = try_ui_fn session "ui/nav" in
  (chrome ?nav_html ~session ~title content)

(* Request-body cap: read_body accumulates the whole body in memory, so
   an unbounded read lets a client exhaust memory. Cap at PP_MAX_BODY_BYTES
   (default 1 MiB); on exceed, raise Body_too_large — Http.launch maps it
   to a 413. Uploads use http_media.read_body_limited (5 MiB) unchanged. *)
exception Body_too_large

let max_body_bytes =
  match Sys.getenv_opt "PP_MAX_BODY_BYTES" with
  | Some s ->
      (match int_of_string_opt s with
       | Some n when n > 0 -> n
       | _ -> 1024 * 1024)
  | None -> 1024 * 1024

let read_body ?(max_bytes = max_body_bytes) (reqd : Httpun.Reqd.t) : string =
  let body = Httpun.Reqd.request_body reqd in
  (* The on_read callback may run on the connection fiber, not the handler
     fiber — so signal overflow via the promise instead of raising inside
     the callback, guaranteeing the exception surfaces in read_body's
     caller where launch's 413 handler can catch it. *)
  let promise, resolver = Eio.Promise.create () in
  let buf = Buffer.create 1024 in
  let rec sched () =
    Httpun.Body.Reader.schedule_read body
      ~on_eof:(fun () ->
        Eio.Promise.resolve resolver (`Ok (Buffer.contents buf)))
      ~on_read:(fun bs ~off ~len ->
        if Buffer.length buf + len > max_bytes then begin
          Eio.Promise.resolve resolver `Too_large
          (* Stop rescheduling: the oversized request is abandoned and
             answered with 413; the connection is closed after the reply. *)
        end else begin
          Buffer.add_string buf (Bigstringaf.substring bs ~off ~len);
          sched ()
        end)
  in
  sched ();
  match Eio.Promise.await promise with
  | `Ok s -> s
  | `Too_large -> raise Body_too_large

(* percent/query decoding lives in Http_kit (one implementation; was
   duplicated here as url_decode and in Http_code as pct_decode).
   url_decode mapped '+' to space and decoded %XX but ATE the two hex
   characters of a malformed escape; Http_kit.pct_decode preserves them. *)
let url_decode = Http_kit.pct_decode

(** application/x-www-form-urlencoded / query component encode. *)
let url_encode (s : string) : string =
  let buf = Buffer.create (String.length s * 2) in
  String.iter
    (function
      | ('A' .. 'Z' | 'a' .. 'z' | '0' .. '9' | '-' | '_' | '.' | '~') as c ->
          Buffer.add_char buf c
      | ' ' -> Buffer.add_string buf "%20"
      | c -> Buffer.add_string buf (Printf.sprintf "%%%02X" (Char.code c)))
    s;
  Buffer.contents buf

(** Same-origin relative path (+ optional query/hash) for post-login return.
    Rejects scheme-relative URLs, off-site targets, and control chars.
    Colons are allowed only in the query/fragment (e.g. url=https://…),
    never in the path (blocks scheme smuggling). *)
let safe_internal_next (candidate : string) : string option =
  let s = String.trim candidate in
  let len = String.length s in
  if len = 0 || len > 2048 then None
  else if s.[0] <> '/' then None
  else if len >= 2 && s.[1] = '/' then None
  else if String.contains s '\n' || String.contains s '\r' then None
  else
    let path_part =
      match String.index_opt s '?', String.index_opt s '#' with
      | Some q, Some h -> String.sub s 0 (min q h)
      | Some q, None -> String.sub s 0 q
      | None, Some h -> String.sub s 0 h
      | None, None -> s
    in
    if String.contains path_part ':' then None else Some s

let form_field (body : string) (name : string) : string option =
  let pairs = String.split_on_char '&' body in
  let rec find = function
    | [] -> None
    | p :: rest ->
        (match String.split_on_char '=' p with
         | k :: vs ->
             if url_decode k = name then
               Some (url_decode (String.concat "=" vs))
             else find rest
         | _ -> find rest)
  in
  find pairs

let parse_form_body (body : string) : (string * string) list =
  if body = "" then []
  else
    String.split_on_char '&' body
    |> List.filter_map (fun p ->
           if p = "" then None
           else
             match String.split_on_char '=' p with
             | k :: vs ->
                 Some (url_decode k, url_decode (String.concat "=" vs))
             | _ -> None)

(** Merge query + form params; form fields win on key conflict (it33). *)
let merge_params ~(query : (string * string) list)
    ~(form : (string * string) list) : (string * string) list =
  let tbl = Hashtbl.create 16 in
  List.iter (fun (k, v) -> Hashtbl.replace tbl k v) query;
  List.iter (fun (k, v) -> Hashtbl.replace tbl k v) form;
  Hashtbl.fold (fun k v acc -> (k, v) :: acc) tbl []

let parse_query (target : string) : (string * string) list =
  match String.index_opt target '?' with
  | None -> []
  | Some i ->
      let q = String.sub target (i + 1) (String.length target - i - 1) in
      String.split_on_char '&' q
      |> List.filter_map (fun p ->
             match String.split_on_char '=' p with
             | k :: vs ->
                 Some (url_decode k, url_decode (String.concat "=" vs))
             | _ -> None)

(* One implementation in Http_kit; re-exported here because the http_*
   pages open Http_core and call it unqualified. *)
let query_param = Http_kit.query_param

(* ------------------------------------------------------------------
   REQUEST BODY SHAPE — one parser for the JSON-else-form POST handlers.

   Six handlers (http_pages api_eval/api_prim, http_agent api_agent/
   api_agent_task/repl_llm/ai_propose) used to hand-roll the same
   "try Yojson, catch, fall back to form fields" scaffolding, each with
   its own drift-prone copy. One shape decision, made here:

     - Body_fields: body is a JSON object — read fields from it.
     - Body_other:  body parses as JSON but is not an object (bare
                    string/array/number) — handlers use their defaults,
                    NOT the form fallback (a JSON array like
                    ["prompt=x"] must not be sniffed as a form).
     - Body_form:   not JSON at all — read urlencoded form fields. *)
type body_shape =
  | Body_fields of (string * Yojson.Safe.t) list
  | Body_other
  | Body_form

let parse_body (body : string) : body_shape =
  match Yojson.Safe.from_string body with
  | `Assoc items -> Body_fields items
  | _ -> Body_other
  | exception _ -> Body_form

(* Read a string field out of parsed [Body_fields]; missing/non-string
   falls back to [default]. Non-string fields (bools, ints, arg lists)
   stay at the call site via List.assoc_opt. *)
let json_field_str ?(default = "")
    (fields : (string * Yojson.Safe.t) list) (name : string) : string =
  match List.assoc_opt name fields with
  | Some (`String s) -> s
  | _ -> default

let max_user_body_bytes = 64 * 1024

(* THE request-body cap — one table for every body-reading entry point
   (i-1788671135-a; replaces the drifted pair http.ml route_body_cap for
   the user-route pipeline vs Http_media.request_body_cap for the media
   endpoints: same multipart answer, disagreement everywhere else, so a
   future fix to one silently missed the other). Two explicit body
   classes consult one policy:

   - `Form — user-route POST bodies, INCLUDING anonymous public-route
     POSTs (/guestbook, /signup are public-route). Multipart may carry
     media files for package upload flows (e.g. music) up to the audio
     ceiling plus framing slack; every other body keeps the 64 KiB form
     cap — deliberately NOT the media ceilings, so unauthenticated
     surfaces keep their small per-request memory bound.

   - `Media — the dedicated media endpoints (/api/media, /media/upload):
     multipart as above; application/json carries base64 (4/3 byte
     inflation) so it rides an audio-inflated ceiling; any content type
     is a candidate raw media body so it gets the per-type media ceiling
     (audio >> images/pdf); a missing content type fails parse_upload_body
     anyway and keeps the modest 5 MiB read ceiling.

   Handlers parse these bodies via (request-multipart) and store the
   file part via (media-put-raw). read_body raises Body_too_large at
   the cap — Http.launch maps it to a 413. *)
type body_class = [ `Form | `Media ]

let request_body_cap ~(kind : body_class) (content_type : string option) : int
  =
  let audio = Media.max_http_audio_bytes in
  match (kind, content_type) with
  | `Form, Some ct when String.starts_with ~prefix:"multipart/form-data" (String.lowercase_ascii (String.trim ct))
    -> audio + 65536
  | `Form, _ -> max_user_body_bytes
  | `Media, None -> Media.max_http_bytes
  | `Media, Some ct ->
      let ct = String.lowercase_ascii (String.trim ct) in
      if String.starts_with ~prefix:"multipart/form-data" ct then audio + 65536
      else if String.starts_with ~prefix:"application/json" ct then
        ((audio * 4) / 3) + 4096
      else Media.max_http_bytes_for ct

let redirect_response (reqd : Httpun.Reqd.t) (location : string) : unit =
  let headers =
    Httpun.Headers.of_list
      ([ ("location", location)
       ; ("content-length", "0")
       ] @ Timing.timing_header ()
       @ security_headers ())
  in
  let resp = Httpun.Response.create ~headers `See_other in
  safe_respond_with_string reqd resp ""

let require_login_redirect (reqd : Httpun.Reqd.t) ~(path : string)
    ~(target : string) : unit =
  if String.length path >= 5 && String.sub path 0 5 = "/api/" then
    unauthorized_api reqd
  else if path = "/" then
    (* Public host: anonymous workspace root → welcome landing. *)
    redirect_response reqd "/welcome"
  else
    match safe_internal_next target with
    | Some next when next <> "/login" && not (String.starts_with ~prefix:"/login?" next)
      ->
        redirect_response reqd ("/login?next=" ^ url_encode next)
    | _ -> redirect_response reqd "/login"

let login_form_page ?(error = "") ?(next = "") (reqd : Httpun.Reqd.t) : unit =
  let err =
    if error = "" then HTML.div [] []
    else HTML.p [HTML.class_ "err"] [txt "%s" error]
  in
  let next =
    let from_arg = String.trim next in
    let candidate =
      if from_arg <> "" then from_arg
      else
        let target = (Httpun.Reqd.request reqd).Httpun.Request.target in
        Option.value (query_param target "next") ~default:""
    in
    match safe_internal_next candidate with Some n -> n | None -> ""
  in
  let next_field =
    if next = "" then HTML.div [] []
    else
      HTML.input
        [ HTML.type_ "hidden"
        ; HTML.name "next"
        ; HTML.value "%s" next
        ]
  in
  (* html_response owns the document (html/head/body); this page is only
     the card fragment plus its stylesheet. It used to build a complete
     second HTML document that html_response then wrapped in another one
     (double DOCTYPE, nested html/head, login stylesheet demoted into the
     outer body) — i-1788670686-b. *)
  let login_css =
    "body{font-family:ui-monospace,Menlo,monospace;max-width:28rem;
           margin:4rem auto;padding:1rem;background:#f4f1ea;color:#1a1a1a}
           .card{border:2px solid #1a1a1a;background:#fff;padding:1.25rem}
           h1{font-size:1.25rem;margin:0 0 1rem}
           label{display:block;margin:.75rem 0 .25rem;font-size:.85rem}
           input[type=text],input[type=password]{width:100%;box-sizing:border-box;
           border:1px solid #1a1a1a;padding:.4rem;font:inherit}
           button{margin-top:1rem;border:2px solid #1a1a1a;background:#1a1a1a;
           color:#fff;padding:.45rem .9rem;font:inherit;cursor:pointer}
           .err{color:#8b0000;margin:.5rem 0}
           .muted{color:#555;font-size:.85rem;margin-top:1rem}"
  in
  let card =
    HTML.div [HTML.class_ "card"] [
      HTML.h1 [] [txt "Sign in"];
      err;
      HTML.form [HTML.method_ `POST; HTML.action "/login"] [
        next_field;
        HTML.label [HTML.for_ "username"] [txt "Username"];
        HTML.input [HTML.type_ "text"; HTML.name "username";
                    HTML.id "username"; HTML.required;
                    HTML.autocomplete `username];
        HTML.label [HTML.for_ "password"] [txt "Password"];
        HTML.input [HTML.type_ "password"; HTML.name "password";
                    HTML.id "password"; HTML.required;
                    HTML.autocomplete `current_password];
        HTML.button [HTML.type_ "submit"] [txt "Log in"];
      ];
      HTML.p [HTML.class_ "muted"] [
        txt "Your garden: username/personal after login.";
      ];
    ]
  in
  html_response reqd ~css:login_css card

let post_login (session : Session.t) ?source_ip (reqd : Httpun.Reqd.t) : unit =
  let body = read_body reqd in
  let username =
    Option.value (form_field body "username") ~default:"" |> String.trim
  in
  let password = Option.value (form_field body "password") ~default:"" in
  let next_raw = Option.value (form_field body "next") ~default:"" in
  let next_ok = safe_internal_next next_raw in
  if username = "" || password = "" then begin
    login_form_page ~error:"Invalid username or password"
      ?next:(match next_ok with Some n -> Some n | None -> None) reqd;
    ()
  end else
    let store = Session.store session in
    let user_opt =
      Auth_store.verify_password store ~username ~password ?source_ip ()
    in
    match user_opt with
    | None ->
        login_form_page ~error:"Invalid username or password"
          ?next:(match next_ok with Some n -> Some n | None -> None) reqd;
        ()
    | Some user ->
        let minted =
          Auth_store.mint_session store ~user_id:user.Auth_store.id
            ?source_ip ()
        in
        (match minted with
         | Error e ->
             login_form_page ~error:("Login failed: " ^ e)
               ?next:(match next_ok with Some n -> Some n | None -> None) reqd;
             ()
         | Ok token ->
             let () =
               attach_from_user session user ~auth_token:(Some token)
                 ~checkout_personal_now:true ()
             in
             let location =
               match next_ok with
               | Some n -> n
               | None ->
                   (match base_domain () with
                    | Some base ->
                        (* Prefer relative if already on garden host; else absolute. *)
                        let headers = header_list (Httpun.Reqd.request reqd) in
                        (match classify_host headers with
                         | Host_garden g when g = user.Auth_store.username ->
                             "/filmstrip"
                         | _ ->
                             (* garden_url is https — never bounce a fresh
                                session cookie over plain http. *)
                             garden_url ~username:user.Auth_store.username
                               ~path:"/filmstrip")
                    | None -> "/filmstrip")
             in
             redirect_with_cookie reqd ~location
               ~set_cookie:
                 (set_cookie_header
                    ~force_secure:(request_is_https (header_list (Httpun.Reqd.request reqd)))
                    ~token ());
             ())

let post_logout (session : Session.t) (reqd : Httpun.Reqd.t) : unit =
  let headers = header_list (Httpun.Reqd.request reqd) in
  let token = cookie_value headers cookie_name in
  let store = Session.store session in
  let () =
    match token with
    | Some t when t <> "" -> Auth_store.revoke_session store ~raw_token:t ()
    | _ -> ()
  in
  Session.clear_auth_token session;
  redirect_with_cookie reqd ~location:"/login"
    ~set_cookie:(clear_cookie_header ());
  ()

(** One-shot display of a freshly issued API token (never stored in URL). *)
let admin_token_once_page ~(session : Session.t) ~(reqd : Httpun.Reqd.t)
    ~(username : string) ~(raw : string) : unit =
  html_response reqd ~session
    (chrome ~session ~title:"API token" [
       HTML.div [HTML.class_ "card"] [
         HTML.h2 [] [txt "Token issued"];
         HTML.p [] [
           txt "Copy now — shown once. User: ";
           HTML.code [] [txt "%s" username];
         ];
         HTML.p [] [HTML.code [] [txt "%s" raw]];
         HTML.p [HTML.class_ "muted"] [
           txt "Use as Authorization: Bearer <token> for /api/eval.";
         ];
         HTML.p [] [HTML.a [HTML.href "/admin/users"] [txt "Back to users"]];
       ];
     ])

let admin_err ~(session : Session.t) ~(reqd : Httpun.Reqd.t) ~title msg =
  html_response reqd ~session ~status:`Bad_request
    (chrome ~session ~title [
       HTML.p [HTML.class_ "err"] [txt "%s" msg];
       HTML.p [] [HTML.a [HTML.href "/admin/users"] [txt "Back"]];
     ]);
  ()

let admin_users_page (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  if not (Session.is_admin session) then begin
    html_response reqd ~session ~status:`Forbidden
      (chrome ~session ~title:"Forbidden" [
         HTML.p [HTML.class_ "err"] [txt "admin only"];
       ]);
    ()
  end else
    let store = Session.store session in
    let users = Auth_store.list_users store in
    (* Per-user promote flag + API tokens (admin agent/token surface —
       BORGE-1785120601). *)
    let user_extras =
      List.map
        (fun (u : Auth_store.user) ->
          let promote =
            if u.Auth_store.user_type = "human" then
              Auth_store.get_allow_agent_promote store ~user_id:u.id
            else false
          in
          let tokens = Auth_store.list_tokens store ~user_id:u.id in
          (u, promote, tokens))
        users
    in
    let human_names =
      List.filter_map
        (fun (u : Auth_store.user) ->
          if u.user_type = "human" then Some u.username else None)
        users
    in
    let rows =
      List.map
        (fun ((u : Auth_store.user), promote, _tokens) ->
          let promote_cell =
            if u.user_type <> "human" then
              HTML.td [] [txt "—"]
            else
              HTML.td [] [
                HTML.form
                  [ HTML.method_ `POST; HTML.action "/admin/users" ]
                  [ HTML.input
                      [ HTML.type_ "hidden"; HTML.name "action";
                        HTML.value "set_allow_agent_promote" ]
                  ; HTML.input
                      [ HTML.type_ "hidden"; HTML.name "user_id";
                        HTML.value "%s" u.id ]
                  ; HTML.input
                      [ HTML.type_ "hidden"; HTML.name "value";
                        HTML.value (if promote then "0" else "1") ]
                  ; HTML.button [HTML.type_ "submit"]
                      [ txt "%s"
                          (if promote then "on (click=off)"
                           else "off (click=on)") ]
                  ]
              ]
          in
          HTML.tr [] [
            HTML.td [] [txt "%s" u.username];
            HTML.td [] [txt "%s" u.user_type];
            HTML.td [] [txt "%s" (if u.is_admin then "yes" else "no")];
            promote_cell;
            HTML.td [] [HTML.code [] [txt "%s" u.id]];
            HTML.td [] [
              HTML.form
                [ HTML.method_ `POST; HTML.action "/admin/users" ]
                [ HTML.input
                    [ HTML.type_ "hidden"; HTML.name "action";
                      HTML.value "set_user_type" ]
                ; HTML.input
                    [ HTML.type_ "hidden"; HTML.name "user_id";
                      HTML.value "%s" u.id ]
                ; HTML.input
                    [ HTML.type_ "hidden"; HTML.name "user_type";
                      HTML.value
                        (if u.user_type = "agent" then "human"
                         else "agent") ]
                ; HTML.button [HTML.type_ "submit"]
                    [ txt "%s"
                        (if u.user_type = "agent" then "Make human"
                         else "Make agent") ]
                ];
              HTML.form
                [ HTML.method_ `POST; HTML.action "/admin/users" ]
                [ HTML.input
                    [ HTML.type_ "hidden"; HTML.name "action";
                      HTML.value "revoke_sessions" ]
                ; HTML.input
                    [ HTML.type_ "hidden"; HTML.name "user_id";
                      HTML.value "%s" u.id ]
                ; HTML.button [HTML.type_ "submit"] [txt "Revoke sessions"]
                ];
              HTML.form
                [ HTML.method_ `POST; HTML.action "/admin/users" ]
                [ HTML.input
                    [ HTML.type_ "hidden"; HTML.name "action";
                      HTML.value "delete_user" ]
                ; HTML.input
                    [ HTML.type_ "hidden"; HTML.name "user_id";
                      HTML.value "%s" u.id ]
                ; HTML.button
                    [ HTML.type_ "submit";
                      HTML.onclick
                        "return confirm('Delete this user? Credentials and \
                         sessions are removed permanently.');" ]
                    [txt "Delete"]
                ];
              HTML.form
                [ HTML.method_ `POST; HTML.action "/admin/users" ]
                [ HTML.input
                    [ HTML.type_ "hidden"; HTML.name "action";
                      HTML.value "issue_token" ]
                ; HTML.input
                    [ HTML.type_ "hidden"; HTML.name "user_id";
                      HTML.value "%s" u.id ]
                ; HTML.input
                    [ HTML.type_ "text"; HTML.name "label";
                      HTML.placeholder "label (optional)" ]
                ; HTML.button [HTML.type_ "submit"] [txt "Issue token"]
                ];
            ];
          ])
        user_extras
    in
    let token_sections =
      List.filter_map
        (fun ((u : Auth_store.user), _p, tokens) ->
          match tokens with
          | [] -> None
          | ts ->
              let trows =
                List.map
                  (fun (tm : Auth_store.token_meta) ->
                    let lab =
                      match tm.label with Some l -> l | None -> "(none)"
                    in
                    let last =
                      match tm.last_used_at with
                      | Some s -> s
                      | None -> "never"
                    in
                    HTML.tr [] [
                      HTML.td [] [HTML.code [] [txt "%s" tm.id]];
                      HTML.td [] [txt "%s" lab];
                      HTML.td [] [txt "…%s" tm.token_last4];
                      HTML.td [] [txt "%s" tm.created_at];
                      HTML.td [] [txt "%s" last];
                      HTML.td [] [
                        HTML.form
                          [ HTML.method_ `POST; HTML.action "/admin/users" ]
                          [ HTML.input
                              [ HTML.type_ "hidden"; HTML.name "action";
                                HTML.value "rotate_token" ]
                          ; HTML.input
                              [ HTML.type_ "hidden"; HTML.name "credential_id";
                                HTML.value "%s" tm.id ]
                          ; HTML.input
                              [ HTML.type_ "hidden"; HTML.name "user_id";
                                HTML.value "%s" u.id ]
                          ; HTML.button [HTML.type_ "submit"] [txt "Rotate"]
                          ];
                        HTML.form
                          [ HTML.method_ `POST; HTML.action "/admin/users" ]
                          [ HTML.input
                              [ HTML.type_ "hidden"; HTML.name "action";
                                HTML.value "revoke_token" ]
                          ; HTML.input
                              [ HTML.type_ "hidden"; HTML.name "credential_id";
                                HTML.value "%s" tm.id ]
                          ; HTML.button [HTML.type_ "submit"] [txt "Revoke"]
                          ];
                      ];
                    ])
                  ts
              in
              Some
                (HTML.div [HTML.class_ "card"] [
                   HTML.h3 [] [txt "Tokens: %s" u.username];
                   HTML.table [] [
                     HTML.thead [] [
                       HTML.tr [] [
                         HTML.th [] [txt "id"];
                         HTML.th [] [txt "label"];
                         HTML.th [] [txt "last4"];
                         HTML.th [] [txt "created"];
                         HTML.th [] [txt "last used"];
                         HTML.th [] [txt "actions"];
                       ];
                     ];
                     HTML.tbody [] trows;
                   ];
                 ]))
        user_extras
    in
    let parent_options =
      match human_names with
      | [] -> [ HTML.option [HTML.value ""] "%s" "(no humans)" ]
      | names ->
          List.map
            (fun n -> HTML.option [HTML.value "%s" n] "%s" n)
            names
    in
    let body =
      chrome ~session ~title:"Users" [
        HTML.div [HTML.class_ "card"] [
          HTML.h2 [] [txt "Users"];
          HTML.p [HTML.class_ "muted"] [
            txt
              "Agents, API tokens, and allow_agent_promote. Raw tokens are \
               shown once after issue/rotate.";
          ];
          HTML.table [] [
            HTML.thead [] [
              HTML.tr [] [
                HTML.th [] [txt "username"];
                HTML.th [] [txt "type"];
                HTML.th [] [txt "admin"];
                HTML.th [] [txt "agent promote"];
                HTML.th [] [txt "id"];
                HTML.th [] [txt "actions"];
              ];
            ];
            HTML.tbody [] rows;
          ];
        ];
        HTML.div [] token_sections;
        HTML.div [HTML.class_ "card"] [
          HTML.h2 [] [txt "Create user"];
          HTML.form [HTML.method_ `POST; HTML.action "/admin/users"] [
            HTML.input
              [ HTML.type_ "hidden"; HTML.name "action";
                HTML.value "create" ];
            HTML.p [] [
              HTML.label [] [txt "username "];
              HTML.input [HTML.type_ "text"; HTML.name "username"; HTML.required];
            ];
            HTML.p [] [
              HTML.label [] [txt "password "];
              HTML.input [HTML.type_ "password"; HTML.name "password"; HTML.required];
            ];
            HTML.p [] [
              HTML.label [] [
                HTML.input [HTML.type_ "checkbox"; HTML.name "is_admin"; HTML.value "1"];
                txt " is_admin";
              ];
            ];
            HTML.button [HTML.type_ "submit"] [txt "Create"];
          ];
        ];
        HTML.div [HTML.class_ "card"] [
          HTML.h2 [] [txt "Create agent"];
          HTML.p [HTML.class_ "muted"] [
            txt "Creates <parent>/agent (idempotent). No password — use API tokens.";
          ];
          HTML.form [HTML.method_ `POST; HTML.action "/admin/users"] [
            HTML.input
              [ HTML.type_ "hidden"; HTML.name "action";
                HTML.value "create_agent" ];
            HTML.p [] [
              HTML.label [] [txt "parent human "];
              HTML.select [HTML.name "parent_username"; HTML.required]
                parent_options;
            ];
            HTML.button [HTML.type_ "submit"] [txt "Create agent"];
          ];
        ];
        HTML.p [] [
          HTML.form [HTML.method_ `POST; HTML.action "/logout"] [
            HTML.button [HTML.type_ "submit"] [txt "Log out"];
          ];
        ];
      ]
    in
    html_response reqd ~session body;
    ()

let post_admin_users (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  if not (Session.is_admin session) then begin
    html_response reqd ~session ~status:`Forbidden
      (chrome ~session ~title:"Forbidden" [
         HTML.p [HTML.class_ "err"] [txt "admin only"];
       ]);
    ()
  end else
    let body = read_body reqd in
    let action =
      Option.value (form_field body "action") ~default:"create"
      |> String.trim
    in
    let store = Session.store session in
    let field name =
      Option.value (form_field body name) ~default:"" |> String.trim
    in
    match action with
    | "delete_user" ->
        let user_id = field "user_id" in
        if user_id = "" then
          admin_err ~session ~reqd ~title:"Delete user" "user_id required"
        else
          (* Same lockout guards as the delete-user prim: never delete
             yourself (loses the admin session), never delete the last
             admin (unreachable habitat). *)
          let me =
            Auth_store.get_user_by_username store (Session.username session)
          in
          let target = Auth_store.get_user_by_id store user_id in
          let deny msg =
            admin_err ~session ~reqd ~title:"Delete user" msg
          in
          (match me with
           | Some m when m.Auth_store.id = user_id ->
               deny "refusing to delete your own account"
           | _ ->
               (match target with
                | None -> deny "no such user"
                | Some tu when tu.Auth_store.is_admin ->
                    let admins =
                      List.filter
                        (fun (u : Auth_store.user) -> u.Auth_store.is_admin)
                        (Auth_store.list_users store)
                    in
                    if List.length admins <= 1 then
                      deny "refusing to delete the last admin"
                    else
                      let r = Auth_store.delete_user store ~user_id in
                      (match r with
                       | Error e -> deny e
                       | Ok _n ->
                           let () =
                             Auth_store.log_auth store ~user_id
                               ~kind:"admin_delete_user" ~success:true ()
                           in
                           redirect_response reqd "/admin/users";
                           ())
                | Some _ ->
                    let r = Auth_store.delete_user store ~user_id in
                    (match r with
                     | Error e -> deny e
                     | Ok _n ->
                         let () =
                           Auth_store.log_auth store ~user_id
                             ~kind:"admin_delete_user" ~success:true ()
                         in
                         redirect_response reqd "/admin/users";
                         ())))
    | "revoke_sessions" ->
        let user_id = field "user_id" in
        if user_id = "" then
          admin_err ~session ~reqd ~title:"Revoke sessions" "user_id required"
        else
          let n = Auth_store.revoke_all_sessions store ~user_id in
          let () =
            Auth_store.log_auth store ~user_id ~kind:"admin_revoke_sessions"
              ~success:true ()
          in
          ignore n;
          redirect_response reqd "/admin/users";
          ()
    | "create_agent" ->
        let parent = field "parent_username" in
        if parent = "" then
          admin_err ~session ~reqd ~title:"Create agent" "parent_username required"
        else
          let r = Auth_store.create_agent store ~parent_username:parent in
          (match r with
           | Error e -> admin_err ~session ~reqd ~title:"Create agent" e
           | Ok _u ->
               redirect_response reqd "/admin/users";
               ())
    | "issue_token" ->
        let user_id = field "user_id" in
        let label =
          match field "label" with "" -> None | s -> Some s
        in
        if user_id = "" then
          admin_err ~session ~reqd ~title:"Issue token" "user_id required"
        else
          let uopt = Auth_store.get_user_by_id store user_id in
          (match uopt with
           | None ->
               admin_err ~session ~reqd ~title:"Issue token" "no such user"
           | Some u ->
               let r =
                 Auth_store.issue_token store ~user_id ~label:label ()
               in
               (match r with
                | Error e -> admin_err ~session ~reqd ~title:"Issue token" e
                | Ok raw ->
                    admin_token_once_page ~session ~reqd
                      ~username:u.username ~raw;
                    ()))
    | "revoke_token" ->
        let credential_id = field "credential_id" in
        if credential_id = "" then
          admin_err ~session ~reqd ~title:"Revoke token"
            "credential_id required"
        else
          let r = Auth_store.revoke_token store ~credential_id in
          (match r with
           | Error e -> admin_err ~session ~reqd ~title:"Revoke token" e
           | Ok () ->
               redirect_response reqd "/admin/users";
               ())
    | "rotate_token" ->
        let credential_id = field "credential_id" in
        let user_id = field "user_id" in
        let label =
          match field "label" with "" -> None | s -> Some s
        in
        if credential_id = "" || user_id = "" then
          admin_err ~session ~reqd ~title:"Rotate token"
            "credential_id and user_id required"
        else
          let uopt = Auth_store.get_user_by_id store user_id in
          (match uopt with
           | None ->
               admin_err ~session ~reqd ~title:"Rotate token" "no such user"
           | Some u ->
               let r =
                 match label with
                 | Some s ->
                     Auth_store.rotate_token store ~credential_id ~user_id
                       ~label:s ()
                 | None ->
                     Auth_store.rotate_token store ~credential_id ~user_id ()
               in
               (match r with
                | Error e -> admin_err ~session ~reqd ~title:"Rotate token" e
                | Ok raw ->
                    admin_token_once_page ~session ~reqd
                      ~username:u.username ~raw;
                    ()))
    | "set_allow_agent_promote" ->
        let user_id = field "user_id" in
        let value =
          match field "value" with
          | "1" | "on" | "true" | "yes" -> true
          | _ -> false
        in
        if user_id = "" then
          admin_err ~session ~reqd ~title:"Agent promote" "user_id required"
        else
          let r =
            Auth_store.set_allow_agent_promote store ~user_id ~value
          in
          (match r with
           | Error e -> admin_err ~session ~reqd ~title:"Agent promote" e
           | Ok () ->
               redirect_response reqd "/admin/users";
               ())
    | "set_user_type" ->
        let user_id = field "user_id" in
        let utype = field "user_type" in
        if user_id = "" || (utype <> "agent" && utype <> "human") then
          admin_err ~session ~reqd ~title:"Set user type"
            "user_id and user_type (human|agent) required"
        else
          (* Flipping to agent: the acting admin is the owning parent
             (matches the prim + the agent-native chapter flip). The
             store validates parent type/user existence. *)
          let parent_user_id =
            if utype = "agent" then
              (match
                 Auth_store.get_user_by_username store
                   (Session.username session)
               with Some p -> Some p.Auth_store.id | None -> None)
            else None
          in
          let r =
            Auth_store.set_user_type store ~user_id ~user_type:utype
              ~parent_user_id
          in
          (match r with
           | Error e -> admin_err ~session ~reqd ~title:"Set user type" e
           | Ok () ->
               let () =
                 Auth_store.log_auth store ~user_id
                   ~kind:"admin_set_user_type" ~success:true ()
               in
               redirect_response reqd "/admin/users";
               ())
    | "create" | _ ->
        let username = field "username" in
        let password = Option.value (form_field body "password") ~default:"" in
        let is_admin =
          match form_field body "is_admin" with
          | Some ("1" | "on" | "true") -> true
          | _ -> false
        in
        if username = "" || password = "" then
          admin_err ~session ~reqd ~title:"Create user"
            "username and password required"
        else
          let created = Auth_store.create_user store ~username ~is_admin in
          (match created with
           | Error e -> admin_err ~session ~reqd ~title:"Create user" e
           | Ok user ->
               let pw =
                 Auth_store.set_password store ~user_id:user.Auth_store.id
                   ~password
               in
               (match pw with
                | Error e ->
                    html_response reqd ~session ~status:`Internal_server_error
                      (chrome ~session ~title:"Create user" [
                         HTML.p [HTML.class_ "err"] [txt "password: %s" e];
                       ]);
                    ()
                | Ok () ->
                    let () =
                      Auth_store.log_auth store ~user_id:user.Auth_store.id
                        ~kind:"admin_create_user" ~success:true ()
                    in
                    redirect_response reqd "/admin/users";
                    ()))

(** i-1787971303: crypto-random hex string of n bytes (Mirage_crypto_rng,
    never the MT19937 Random state) — used for minted multipart boundaries. *)
let random_hex_bytes (n : int) : string =
  let b = Mirage_crypto_rng.generate n in
  let buf = Buffer.create (n * 2) in
  String.iter
    (fun c -> Buffer.add_string buf (Printf.sprintf "%02x" (Char.code c)))
    b;
  Buffer.contents buf

(** Generate a MIME boundary that does not appear in any part body. *)
let fresh_multipart_boundary (bodies : string list) : string =
  let rec try_n n =
    if n > 8 then
      raise
        (Pricklypear_lisp.Ast.Interp_error
           (Pricklypear_lisp.Ast.User_error
              ("multipart: could not choose a unique boundary", "bad-args")))
    else
      let b = "pp" ^ random_hex_bytes 8 in
      if List.exists (fun body ->
           let rec find i =
             let bl = String.length b and n = String.length body in
             if i + bl > n then false
             else if String.sub body i bl = b then true
             else find (i + 1)
           in
           find 0)
         bodies
      then try_n (n + 1)
      else b
  in
  try_n 0

(** Frame a multipart/mixed body (eager v1). Peer-gone on write is swallowed.
    Streaming write+flush per part is available later; the reactive payoff is
    multiple targeted parts in one response. Effect-safe: no Eio.Promise
    await on the handler fiber (Continuation_already_resumed under Prim_call). *)
let multipart_response (reqd : Httpun.Reqd.t)
    (mp : Prims_pure.mime_multipart) : unit =
  let bodies = List.map (fun (p : Prims_pure.mime_part) -> p.body) mp.parts in
  let boundary = fresh_multipart_boundary bodies in
  let buf = Buffer.create 256 in
  List.iter
    (fun (p : Prims_pure.mime_part) ->
      Buffer.add_string buf ("--" ^ boundary ^ "\r\n");
      Buffer.add_string buf ("Content-Type: " ^ p.content_type ^ "\r\n");
      (match p.target with
       | Some t -> Buffer.add_string buf ("HX-Target: " ^ t ^ "\r\n")
       | None -> ());
      (match p.swap with
       | Some s -> Buffer.add_string buf ("HX-Swap: " ^ s ^ "\r\n")
       | None -> ());
      (match p.id with
       | Some i -> Buffer.add_string buf ("HX-Part-ID: " ^ i ^ "\r\n")
       | None -> ());
      Buffer.add_string buf "\r\n";
      Buffer.add_string buf p.body;
      Buffer.add_string buf "\r\n")
    mp.parts;
  Buffer.add_string buf ("--" ^ boundary ^ "--\r\n");
  let body = Buffer.contents buf in
  let headers =
    let base =
      [ ( "content-type"
        , "multipart/mixed; boundary=" ^ boundary )
      ; ("cache-control", "no-cache")
      ; ("content-length", string_of_int (String.length body))
      ]
    in
    let base =
      match mp.envelope_target with
      | Some t -> ("hx-target", t) :: base
      | None -> base
    in
    let base =
      match mp.envelope_swap with
      | Some s -> ("hx-swap", s) :: base
      | None -> base
    in
    Httpun.Headers.of_list base
  in
  let resp = Httpun.Response.create ~headers `OK in
  safe_respond_with_string reqd resp body

(** i-1788670909: ONE status mapping for handler-signalled codes — the
    named common cases, then any valid 3-digit HTTP code passes through
    (Httpun.Status.of_code), and only non-3-digit garbage coerces to 400
    (was: every unknown code silently became 400). *)
let status_of_handler_code (code : int) : Httpun.Status.t =
  match code with
  | 409 -> `Conflict
  | 400 -> `Bad_request
  | 403 -> `Forbidden
  | 404 -> `Not_found
  | 500 -> `Internal_server_error
  | _ -> (try Httpun.Status.of_code code with Failure _ -> `Bad_request)

(* Exposed for unit tests *)
let status_of_handler_code_for_test = status_of_handler_code

let respond_handler_value
    ~(session : Session.t)
    ~(reqd : Httpun.Reqd.t)
    ~(path : string)
    ~(fragment : bool)
    (value : Pricklypear_lisp.Ast.value) : unit =
  (* Pull the per-request snapshot manifest (fiber-local binding, so
     chrome renders this request's identity, not whatever a concurrent
     attach flipped). *)
  let manifest =
    match Request_context.get () with
    | Some ctx -> Request_context.manifest ctx
    | None -> Session.manifest session
  in
  match Primitives.is_bytes value with
  | Some (ctype, max_age, body) ->
      (* Handler returned a non-HTML byte response, e.g. the stylesheet
         face (product-experience.html-builders layout.css-face). Serve
         the real Content-Type; Cache-Control comes from the max-age of
         the sentinel ("0" -> no-cache revalidation). *)
      text_response reqd ~content_type:ctype ?cache:(int_of_string_opt max_age) body
  | None ->
  match Primitives.is_redirect value with
  | Some loc -> redirect_response reqd loc
  | None ->
      (match Primitives.is_status value with
       | Some (code, body) ->
           (* Handler signalled a non-200 status (e.g. op-seq 409).
              Respond with the status + body as a fragment/HTML. *)
           let status = status_of_handler_code code in
           if fragment then fragment_response reqd ~status body
           else
             html_response reqd ~session ~status
               (txt ~raw:true "%s" body)
       | None ->
      (match Primitives.is_multipart value with
       | Some mp -> multipart_response reqd mp
       | None ->
           if fragment then
             let html =
               match Primitives.is_raw_html value with
               | Some raw -> raw
               | None ->
                   (match value with
                    | Pricklypear_lisp.Ast.VStr s -> s
                    | _ -> Pricklypear_lisp.Reader.pp_value value)
             in
             fragment_response reqd html
           else
             let body =
               match Primitives.is_raw_html value with
               | Some raw_html ->
                   chrome ~manifest ~session ~title:path
                     [ txt ~raw:true "%s" raw_html ]
               | None ->
                   (match value with
                    | Pricklypear_lisp.Ast.VStr s ->
                        chrome ~manifest ~session ~title:path
                          [ HTML.p [] [txt "%s" s] ]
                    | _ ->
                        let rendered =
                          Pricklypear_lisp.Reader.pp_value value
                        in
                        chrome ~manifest ~session ~title:path [
                          HTML.pre [] [txt "%s" rendered];
                        ])
             in
             html_response reqd ~session body))

(** i-1788670767: the four per-user settings handlers shared a copy-pasted
    signed-in preamble (anonymous -> /login; user lookup -> continue or
    caller-chosen no-user response). One combinator instead of 4 copies. *)
let with_signed_in_user ~(session : Session.t) ~(reqd : Httpun.Reqd.t)
    ~(no_user : unit -> unit) (k : Auth_store.user -> unit) : unit =
  if Session.username session = "anonymous" then
    redirect_response reqd "/login"
  else
    match
      Auth_store.get_user_by_username (Session.store session)
        (Session.username session)
    with
    | None -> no_user ()
    | Some user -> k user

(** /settings/keys — per-user LLM provider key (auth.user-llm-keys). *)
let settings_keys_page (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  with_signed_in_user ~session ~reqd
    ~no_user:(fun () ->
      html_response reqd ~session ~status:`Unauthorized
        (chrome ~session ~title:"Keys" [
           HTML.p [HTML.class_ "err"] [txt "not signed in"];
         ]);
      ())
    (fun user ->
        let meta =
          Auth_store.get_llm_key_meta (Session.store session)
            ~user_id:user.Auth_store.id
        in
        (* The model dropdown is the provider ABI's own catalog
           (borge/agent.borg llm-config: /models with the RESOLVED key —
           the user's credential when set, else env fallback). No fetch
           or empty catalog -> the free-text input stands. *)
        let models =
          match
            Auth_store.get_llm_key_secret (Session.store session)
              ~user_id:user.Auth_store.id
          with
          | Some (key, m) ->
              Llm_client.list_models
                ~creds:(Some
                  { Llm_client.api_key = key;
                    api_base =
                      (match m.Auth_store.base with
                       | Some b -> b
                       | None -> Llm_client.api_base ());
                    model = "" })
                ()
          | None -> Llm_client.list_models ()
        in
        let current_model =
          match meta with
          | Some m -> Option.value m.Auth_store.model ~default:""
          | None -> ""
        in
        let model_field =
          match models with
          | [] -> HTML.input [HTML.type_ "text"; HTML.name "model"]
          | ms ->
              let ms =
                if current_model <> "" && not (List.mem current_model ms)
                then current_model :: ms
                else ms
              in
              HTML.select [HTML.name "model"]
                (HTML.option [HTML.value ""] "%s" "(server default)"
                 :: List.map
                      (fun mo ->
                        if mo = current_model then
                          HTML.option [HTML.value "%s" mo; HTML.selected] "%s" mo
                        else HTML.option [HTML.value "%s" mo] "%s" mo)
                      ms)
        in
        let status_line =
          match meta with
          | None ->
              if Llm_client.api_key () <> "" then
                "No personal key. Operator LLM_API_KEY env is set (fallback)."
              else
                "No personal key and no LLM_API_KEY env."
          | Some m ->
              Printf.sprintf "Configured · last4=%s%s%s"
                m.last4
                (match m.base with Some b -> " · base=" ^ b | None -> "")
                (match m.model with Some mo -> " · model=" ^ mo | None -> "")
        in
        let body =
          chrome ~session ~title:"LLM keys" [
            HTML.h1 [] [txt "LLM keys"];
            HTML.p [HTML.class_ "muted"] [
              txt "Bring your own provider key. Never shown again after save — only last4.";
            ];
            HTML.p [] [txt "%s" status_line];
            HTML.div [HTML.class_ "card"] [
              HTML.form [HTML.method_ `POST; HTML.action "/settings/keys"] [
                HTML.input [HTML.type_ "hidden"; HTML.name "action"; HTML.value "set"];
                HTML.p [] [
                  HTML.label [] [txt "API key"];
                  HTML.input [HTML.type_ "password"; HTML.name "api_key"; HTML.required];
                ];
                HTML.p [] [
                  HTML.label [] [txt "Base URL (optional)"];
                  HTML.input [HTML.type_ "text"; HTML.name "base";
                              HTML.placeholder "https://api.synthetic.new/openai/v1"];
                ];
                HTML.p [] [
                  HTML.label [] [txt "Model (optional)"];
                  model_field;
                ];
                HTML.button [HTML.type_ "submit"] [txt "Save key"];
              ];
            ];
            HTML.div [HTML.class_ "card"] [
              HTML.form [HTML.method_ `POST; HTML.action "/settings/keys"] [
                HTML.input [HTML.type_ "hidden"; HTML.name "action"; HTML.value "clear"];
                HTML.button [HTML.type_ "submit"] [txt "Clear key"];
              ];
            ];
          ]
        in
        html_response reqd ~session body;
        ())

let post_settings_keys (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  with_signed_in_user ~session ~reqd
    ~no_user:(fun () -> redirect_response reqd "/login")
    (fun user ->
        let body = read_body reqd in
        let action =
          Option.value (form_field body "action") ~default:"set" |> String.trim
        in
        if action = "clear" then
          (* i-1788670767: honor the result — a failed clear must not
             redirect as success (same contract as the set action). *)
          (match
             Auth_store.clear_llm_key (Session.store session)
               ~user_id:user.Auth_store.id
           with
           | Error e ->
               html_response reqd ~session ~status:`Bad_request
                 (chrome ~session ~title:"LLM keys" [
                    HTML.p [HTML.class_ "err"] [txt "%s" e];
                    HTML.p [] [HTML.a [HTML.href "/settings/keys"] [txt "Back"]];
                  ]);
               ()
           | Ok () ->
               redirect_response reqd "/settings/keys";
               ())
        else
          let api_key =
            Option.value (form_field body "api_key") ~default:"" |> String.trim
          in
          let base =
            match form_field body "base" with
            | Some s when String.trim s <> "" -> Some (String.trim s)
            | _ -> None
          in
          let model =
            match form_field body "model" with
            | Some s when String.trim s <> "" -> Some (String.trim s)
            | _ -> None
          in
          let r =
            Auth_store.set_llm_key (Session.store session)
              ~user_id:user.Auth_store.id ~api_key ~base ~model ()
          in
          (match r with
           | Error e ->
               html_response reqd ~session ~status:`Bad_request
                 (chrome ~session ~title:"LLM keys" [
                    HTML.p [HTML.class_ "err"] [txt "%s" e];
                    HTML.p [] [HTML.a [HTML.href "/settings/keys"] [txt "Back"]];
                  ]);
               ()
           | Ok _ ->
               redirect_response reqd "/settings/keys";
               ()))

let settings_ssh_page (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  with_signed_in_user ~session ~reqd
    ~no_user:(fun () -> redirect_response reqd "/login")
    (fun user ->
        let keys =
          Auth_store.list_ssh_keys (Session.store session)
            ~user_id:user.Auth_store.id
        in
        let key_rows =
          List.map
            (fun (k : Auth_store.ssh_key_meta) ->
              let label =
                match k.label with Some l -> l | None -> ""
              in
              HTML.tr [] [
                HTML.td [] [HTML.code [] [txt "%s" k.fingerprint]];
                HTML.td [] [txt "%s" label];
                HTML.td [] [
                  HTML.form
                    [ HTML.method_ `POST; HTML.action "/settings/ssh" ]
                    [ HTML.input
                        [ HTML.type_ "hidden"; HTML.name "action";
                          HTML.value "revoke" ];
                      HTML.input
                        [ HTML.type_ "hidden"; HTML.name "id";
                          HTML.value "%s" k.id ];
                      HTML.button [HTML.type_ "submit"] [txt "Revoke"];
                    ];
                ];
              ])
            keys
        in
        let body =
          chrome ~session ~title:"SSH keys" [
            HTML.h1 [] [txt "SSH keys"];
            HTML.p [HTML.class_ "muted"] [
              txt "Register an OpenSSH public key for the REPL door (auth.user-ssh-repl).";
            ];
            HTML.div [HTML.class_ "card"] [
              HTML.h2 [] [txt "Your keys"];
              (if keys = [] then
                 HTML.p [HTML.class_ "muted"] [txt "No keys yet."]
               else
                 HTML.table [] (
                   HTML.thead [] [
                     HTML.tr [] [
                       HTML.th [] [txt "fingerprint"];
                       HTML.th [] [txt "label"];
                       HTML.th [] [txt ""];
                     ];
                   ]
                   :: key_rows
                 ));
            ];
            HTML.div [HTML.class_ "card"] [
              HTML.h2 [] [txt "Add key"];
              HTML.form [HTML.method_ `POST; HTML.action "/settings/ssh"] [
                HTML.input [HTML.type_ "hidden"; HTML.name "action"; HTML.value "add"];
                HTML.p [] [
                  HTML.label [] [txt "OpenSSH public key"];
                  HTML.textarea [HTML.name "openssh"; HTML.required] "%s" "";
                ];
                HTML.p [] [
                  HTML.label [] [txt "Label (optional)"];
                  HTML.input [HTML.type_ "text"; HTML.name "label"; HTML.placeholder "laptop"];
                ];
                HTML.button [HTML.type_ "submit"] [txt "Add key"];
              ];
            ];
          ]
        in
        html_response reqd ~session body;
        ())

let post_settings_ssh (session : Session.t) (reqd : Httpun.Reqd.t)
  : unit =
  with_signed_in_user ~session ~reqd
    ~no_user:(fun () -> redirect_response reqd "/login")
    (fun user ->
        let body = read_body reqd in
        let action =
          Option.value (form_field body "action") ~default:"add" |> String.trim
        in
        if action = "revoke" then
          let id =
            Option.value (form_field body "id") ~default:"" |> String.trim
          in
          (* i-1788670767: honor the result — a failed revoke must not
             redirect as success (same contract as the add action). *)
          (match
             Auth_store.revoke_ssh_key (Session.store session)
               ~user_id:user.Auth_store.id ~id_or_fingerprint:id
           with
           | Error e ->
               html_response reqd ~session ~status:`Bad_request
                 (chrome ~session ~title:"SSH keys" [
                    HTML.p [HTML.class_ "err"] [txt "%s" e];
                    HTML.p [] [HTML.a [HTML.href "/settings/ssh"] [txt "Back"]];
                  ]);
               ()
           | Ok () ->
               redirect_response reqd "/settings/ssh";
               ())
        else
          let openssh =
            Option.value (form_field body "openssh") ~default:"" |> String.trim
          in
          let label =
            match form_field body "label" with
            | Some s when String.trim s <> "" -> Some (String.trim s)
            | _ -> None
          in
          let r =
            Auth_store.add_ssh_key (Session.store session)
              ~user_id:user.Auth_store.id ~openssh ~label ()
          in
          (match r with
           | Error e ->
               html_response reqd ~session ~status:`Bad_request
                 (chrome ~session ~title:"SSH keys" [
                    HTML.p [HTML.class_ "err"] [txt "%s" e];
                    HTML.p [] [HTML.a [HTML.href "/settings/ssh"] [txt "Back"]];
                  ]);
               ()
           | Ok _ ->
               redirect_response reqd "/settings/ssh";
               ()))

