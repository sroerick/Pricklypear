(** Pricklypear Image — binary media blob store (storage.media).

    Table: media_blobs (migration 007). Shared across branches like
    data_rows; ownership is [author]. Bytes live in bytea; meta path
    never returns the payload over Lisp eval. *)

type meta = {
  id : string;
  author : string;
  content_type : string;
  filename : string option;
  byte_size : int;
  sha256 : string;
  meta_json : string;
  created_at : string;
}

type put_result = {
  id : string;
  content_type : string;
  filename : string option;
  byte_size : int;
  sha256 : string;
}

let max_http_bytes = 5 * 1024 * 1024
(* Audio (music files) routinely dwarfs the image/pdf ceiling. *)
let max_http_audio_bytes = 64 * 1024 * 1024
let max_eval_put_bytes = 256 * 1024

let allowed_content_types =
  [ "image/png"
  ; "image/jpeg"
  ; "image/gif"
  ; "image/webp"
  ; "image/svg+xml"
  ; "application/pdf"
  ; "audio/mpeg" (* .mp3 *)
  ; "audio/ogg" (* .ogg / vorbis / opus *)
  ; "audio/flac" (* .flac *)
  ; "audio/wav" (* .wav *)
  ; "audio/mp4" (* .m4a / aac in mp4 *)
  ; "audio/aac" (* raw ADTS .aac *)
  ; "audio/webm" (* opus in webm (browser recordings) *)
  ; "application/octet-stream" (* files-lens v0: the "anything" suitcase —
       arbitrary personal files sync via pp_files.py. text/html stays
       denied (stored-XSS on inline serving); octet-stream has no active
       content, GET /media serves it inert as a browser download. *)
  ]

(* Friendly aliases normalized to a canonical whitelisted type on
   put, so clients guessing mime by extension still land. *)
let content_type_aliases =
  [ ("audio/mp3", "audio/mpeg")
  ; ("audio/x-mp3", "audio/mpeg")
  ; ("audio/m4a", "audio/mp4")
  ; ("audio/x-m4a", "audio/mp4")
  ; ("audio/x-wav", "audio/wav")
  ; ("audio/wave", "audio/wav")
  ; ("audio/x-flac", "audio/flac")
  ]

let normalize_content_type (ct : string) : string =
  let ct = String.trim (String.lowercase_ascii ct) in
  let base =
    match String.index_opt ct ';' with
    | None -> ct
    | Some i -> String.trim (String.sub ct 0 i)
  in
  match List.assoc_opt base content_type_aliases with
  | Some canon -> canon
  | None -> base

let content_type_allowed (ct : string) : bool =
  List.mem (normalize_content_type ct) allowed_content_types

let is_audio_content_type (ct : string) : bool =
  String.starts_with ~prefix:"audio/" (normalize_content_type ct)

let is_files_content_type (ct : string) : bool =
  normalize_content_type ct = "application/octet-stream"

(* Type-aware upload ceiling: music files get the big one; the files
   flavor rides the same ceiling (64 MiB — chunked upload stays a
   non-goal until the chunk endpoint exists, storage.files-file-lens). *)
let max_http_bytes_for (ct : string) : int =
  if
    is_audio_content_type ct || is_files_content_type ct
  then max_http_audio_bytes
  else max_http_bytes

let sanitize_filename (name : string option) : string option =
  match name with
  | None -> None
  | Some raw ->
      let s = String.trim raw in
      if s = "" then None
      else
        let base =
          match String.rindex_opt s '/' with
          | Some i -> String.sub s (i + 1) (String.length s - i - 1)
          | None ->
              (match String.rindex_opt s '\\' with
               | Some i -> String.sub s (i + 1) (String.length s - i - 1)
               | None -> s)
        in
        let base = String.trim base in
        if base = "" || base = "." || base = ".." then None
        else
          let capped =
            if String.length base > 200 then String.sub base 0 200 else base
          in
          Some capped

let sha256_hex (bytes : string) : string = Auth_password.sha256_hex bytes

let b64_decode_opt (s : string) : string option =
  match Base64.decode ~pad:true s with
  | Ok raw -> Some raw
  | Error _ ->
      (match Base64.decode ~pad:false s with
       | Ok raw -> Some raw
       | Error _ -> None)

let url_of_id (id : string) : string = "/media/" ^ id

let meta_to_yojson (m : meta) : Yojson.Safe.t =
  `Assoc
    [ ("id", `String m.id)
    ; ("author", `String m.author)
    ; ("content_type", `String m.content_type)
    ; ( "filename"
      , match m.filename with Some f -> `String f | None -> `Null )
    ; ("byte_size", `Int m.byte_size)
    ; ("sha256", `String m.sha256)
    ; ("url", `String (url_of_id m.id))
    ; ("created_at", `String m.created_at)
    ; ( "meta"
      , try Yojson.Safe.from_string m.meta_json with _ -> `Assoc [] )
    ]

let meta_to_json_string (m : meta) : string =
  Yojson.Safe.to_string (meta_to_yojson m)

let put_result_to_yojson (r : put_result) : Yojson.Safe.t =
  `Assoc
    [ ("ok", `Bool true)
    ; ("id", `String r.id)
    ; ("content_type", `String r.content_type)
    ; ( "filename"
      , match r.filename with Some f -> `String f | None -> `Null )
    ; ("byte_size", `Int r.byte_size)
    ; ("sha256", `String r.sha256)
    ; ("url", `String (url_of_id r.id))
    ]

(* row-cell accessors live in Row (was a local copy here). *)

let row_to_meta (row : Pgx.row) : meta option =
  match
    ( Row.cell_string row 0
    , Row.cell_string row 1
    , Row.cell_string row 2
    , Row.cell_string row 3
    , Row.cell_int row 4
    , Row.cell_string row 5
    , Row.cell_string row 6
    , Row.cell_string row 7 )
  with
  | ( Some id
    , Some author
    , Some content_type
    , filename_opt
    , Some byte_size
    , Some sha256
    , Some meta_json
    , Some created_at ) ->
      Some
        { id
        ; author
        ; content_type
        ; filename = filename_opt
        ; byte_size
        ; sha256
        ; meta_json
        ; created_at
        }
  | _ -> None

(** Typed put failures (i-1788670909): callers — the HTTP edge and the
    media prims — match this variant instead of sniffing message
    prefixes. A new failure mode is a constructor here and a compile
    error at every match site, not a silently-misclassified 500.
    [put_error_message] renders the exact strings the old
    stringly-typed contract produced (prim output compat). *)
type put_error =
  | Disallowed_content_type of string
  | Empty_body
  | Too_large of int * int  (* got, max *)
  | No_db
  | Store_failed of string  (* rendered failure detail (insert anomaly or SQL exn) *)
  | Quota_exceeded of int * int * int  (* used, incoming, cap *)

let put_error_message (e : put_error) : string =
  match e with
  | Disallowed_content_type ct -> "disallowed content_type: " ^ ct
  | Empty_body -> "empty body"
  | Too_large (got, max) ->
      Printf.sprintf "payload too large (%d > %d)" got max
  | No_db -> "no db connection"
  | Store_failed detail -> detail
  | Quota_exceeded (used, incoming, cap) ->
      Tier_limits.quota_message (used, incoming, cap)

let put
    (store : Store.t)
    ~(author : string)
    ~(content_type : string)
    ~(data : string)
    ?(filename : string option = None)
    ?(meta_json : string = "{}")
    ?(max_bytes : int = max_http_bytes)
    () : (put_result, put_error) result =
  let ct = normalize_content_type content_type in
  if not (content_type_allowed ct) then
    (Error (Disallowed_content_type ct))
  else
    let byte_size = String.length data in
    if byte_size <= 0 then (Error Empty_body)
    else if byte_size > max_bytes then
      (Error (Too_large (byte_size, max_bytes)))
    else
      match Io_db.Db.current_conn store with
      | None -> (Error No_db)
      | Some conn ->
          (* Media storage quota (spec_town_profile P1): under a named
             profile, non-admin authors are capped on summed blob bytes.
             One choke point here covers the HTTP edge AND the
             media-put / media-put-raw prims. Admins exempt; unknown
             authors count as tenants (deny-lean). *)
          let quota_error =
            match Profile.tenant_limits () with
            | None -> None
            | Some limits ->
                let is_admin_rows =
                  Store_db.exec conn
                    ~params:[ Pgx.Value.of_string author ]
                    "SELECT is_admin::int FROM users WHERE username = $1"
                in
                let admin =
                  match is_admin_rows with
                  | row :: _ -> (match Row.cell_int row 0 with Some 1 -> true | _ -> false)
                  | [] -> false
                in
                if admin then None
                else
                    let used_rows =
                      Store_db.exec conn
                        ~params:[ Pgx.Value.of_string author ]
                        ("SELECT coalesce(sum(byte_size),0)::int FROM media_blobs " ^
                         "WHERE author = $1")
                    in
                  let used =
                    match used_rows with
                    | row :: _ ->
                        (match Row.cell_int row 0 with Some n -> n | None -> 0)
                    | [] -> 0
                  in
                  (match
                     Tier_limits.media_ok ~used ~incoming:byte_size
                       ~limit:limits.media_bytes
                     with
                     | Ok () -> None
                     | Error (u, i, l) -> Some (Quota_exceeded (u, i, l)))
          in
          (match quota_error with
           | Some e -> (Error e)
           | None ->
            let fname = sanitize_filename filename in
          let digest = sha256_hex data in
          let meta =
            let m = String.trim meta_json in
            if m = "" then "{}"
            else
              try
                ignore (Yojson.Safe.from_string m);
                m
              with _ -> "{}"
          in
          let sql =
            "INSERT INTO media_blobs \
             (author, content_type, filename, byte_size, sha256, data, meta) \
             VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb) \
             RETURNING id::text"
          in
          (try
      let rows =
                Store_db.exec conn
                  ~params:
                    [ Pgx.Value.of_string author
                    ; Pgx.Value.of_string ct
                    ; (match fname with
                       | Some f -> Pgx.Value.of_string f
                       | None -> Pgx.Value.of_string "")
                    ; Pgx.Value.of_int byte_size
                    ; Pgx.Value.of_string digest
                    ; Pgx.Value.of_binary data
                    ; Pgx.Value.of_string meta
                    ]
                  sql
              in
              match rows with
              | row :: _ ->
                  (match Row.cell_string row 0 with
                   | Some id ->
                       (* Normalize empty filename column to None. *)
                       let filename =
                         match fname with
                         | Some f when f <> "" -> Some f
                         | _ -> None
                       in
                       (Ok
                            { id
                            ; content_type = ct
                            ; filename
                            ; byte_size
                            ; sha256 = digest
                            })
                   | None ->
                       (Error
                          (Store_failed "insert returned no id")))
              | [] -> (Error (Store_failed "insert returned no row"))
      with exn ->
        (Error
           (Store_failed ("store failed: " ^ Printexc.to_string exn)))))

(** Visibility confinement (BORGE-1785695911): a blob readable by [actor]
    iff [actor] authored it or [is_admin]. [None] performs no confinement
    (kernel callers that resolved identity upstream). Applied at the SQL
    layer so list/get/delete agree on one predicate. *)
let visible_sql ~(is_admin : bool) ~(actor_param : int) : string =
  if is_admin then "TRUE"
  else Printf.sprintf "author = $%d" actor_param

let get_meta (store : Store.t) ~(id : string)
  ?(visible_to : (string * bool) option) () : meta option =
  match Io_db.Db.current_conn store with
  | None -> None
  | Some conn ->
      let sql, params =
        match visible_to with
        | Some (actor, is_admin) ->
            (* BORGE-1785695911 regression fix: the admin predicate is
               literal TRUE — no $2 placeholder — so binding the actor
               param unconditionally made pgx reject the statement
               ("supplies 2 parameters, requires 1") and the swallowed
               exception turned every admin GET-by-uuid into a 404. *)
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs WHERE id = $1::uuid AND "
              ^ visible_sql ~is_admin ~actor_param:2
            , if is_admin then [ Pgx.Value.of_string id ]
              else
                [ Pgx.Value.of_string id; Pgx.Value.of_string actor ] )
        | None ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs WHERE id = $1::uuid"
            , [ Pgx.Value.of_string id ] )
      in
      (try
      let rows =
            Store_db.exec conn
              ~params
              sql
          in
          match rows with
          | row :: _ -> (row_to_meta row)
          | [] -> None
    with _ ->
      None)

(** (files-lens) sha256 dedup lookup: newest blob with this digest,
    author-confined via the same visible_sql predicate. The file-lens
    client hashes LOCALLY first and calls this BEFORE uploading — no
    change, zero bytes on the wire. 404 (None) = push it. Not exposed
    as a Lisp prim (bulk-adjacent; HTTP edge only). *)
let get_meta_by_sha256
    (store : Store.t) ~(sha256 : string)
    ~(visible_to : (string * bool) option) () : meta option =
  match Io_db.Db.current_conn store with
  | None -> None
  | Some conn ->
      let sql, params =
        match visible_to with
        | Some (actor, is_admin) ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs WHERE sha256 = $1 AND "
              ^ visible_sql ~is_admin ~actor_param:3
              ^ " ORDER BY created_at DESC LIMIT 1"
            , if is_admin then [ Pgx.Value.of_string sha256 ]
              else
                [ Pgx.Value.of_string sha256; Pgx.Value.of_string actor ] )
        | None ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs WHERE sha256 = $1 \
               ORDER BY created_at DESC LIMIT 1"
            , [ Pgx.Value.of_string sha256 ] )
      in
      (try
        let rows =
          Store_db.exec conn ~params sql
        in
        match rows with
        | row :: _ -> row_to_meta row
        | [] -> None
      with _ -> None)

let get_bytes (store : Store.t) ~(id : string)
  ?(visible_to : (string * bool) option) () : (meta * string) option =
  match Io_db.Db.current_conn store with
  | None -> None
  | Some conn ->
      let sql, params =
        match visible_to with
        | Some (actor, is_admin) ->
            (* Same admin-predicate param discipline as get_meta. *)
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text, data \
               FROM media_blobs WHERE id = $1::uuid AND "
              ^ visible_sql ~is_admin ~actor_param:2
            , if is_admin then [ Pgx.Value.of_string id ]
              else
                [ Pgx.Value.of_string id; Pgx.Value.of_string actor ] )
        | None ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text, data \
               FROM media_blobs WHERE id = $1::uuid"
            , [ Pgx.Value.of_string id ] )
      in
      (try
      let rows =
            Store_db.exec conn
              ~params
              sql
          in
          match rows with
          | row :: _ ->
              (match row_to_meta row, List.nth_opt row 8 with
               | Some m, Some data_cell ->
                   (match Pgx.Value.to_binary data_cell with
                    | Some bytes -> (Some (m, bytes))
                    | None ->
                        (* Text-mode fallback if driver surfaces bytea as hex/escape. *)
                        (match Pgx.Value.to_string data_cell with
                         | Some s -> (Some (m, s))
                         | None -> None))
               | _ -> None)
          | [] -> None
    with _ ->
      None)

let list
    (store : Store.t)
    ?(author : string option = None)
    ?(limit : int = 50)
    () : meta list =
  match Io_db.Db.current_conn store with
  | None -> []
  | Some conn ->
      let limit = max 1 (min 200 limit) in
      let sql, params =
        match author with
        | Some a ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs WHERE author = $1 \
               ORDER BY created_at DESC LIMIT $2"
            , [ Pgx.Value.of_string a; Pgx.Value.of_int limit ] )
        | None ->
            ( "SELECT id::text, author, content_type, \
               NULLIF(filename, ''), byte_size::text, sha256, meta::text, \
               created_at::text \
               FROM media_blobs \
               ORDER BY created_at DESC LIMIT $1"
            , [ Pgx.Value.of_int limit ] )
      in
      (try
      let rows = Store_db.exec conn ~params sql in
          (List.filter_map row_to_meta rows)
    with _ ->
      [])

let delete
    (store : Store.t)
    ~(id : string)
    ~(actor : string)
    ~(is_admin : bool)
  : ([ `Ok of string | `Not_found | `Forbidden ], string) result =
  let meta = get_meta store ~id () in
  match meta with
  | None -> (Ok `Not_found)
  | Some m ->
      if (not is_admin) && m.author <> actor then
        (Ok `Forbidden)
      else
        match Io_db.Db.current_conn store with
        | None -> (Error "no db connection")
        | Some conn ->
            let sql = "DELETE FROM media_blobs WHERE id = $1::uuid" in
            (try
      let _ =
                  Store_db.exec conn
                    ~params:[ Pgx.Value.of_string id ]
                    sql
                in
                (Ok (`Ok id))
    with exn ->
      (Error ("delete failed: " ^ Printexc.to_string exn)))
